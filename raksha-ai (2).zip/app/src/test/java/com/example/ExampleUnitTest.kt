package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testUrlChecker_detectsSuspiciousTldAndApk() {
    val result = UrlChecker.checkUrl("http://sbi-kyc-update.xyz/login.apk")
    assertTrue(result.isSuspicious)
    assertTrue(result.flags.any { it.contains("Direct installable file download") })
    assertTrue(result.flags.any { it.contains("Suspicious top-level domain") })
    assertTrue(result.riskScore >= 70)
  }

  @Test
  fun testRiskEngine_detectsElectricityBillScam() {
    val text = "Dear user, your electricity power will be disconnected tonight at 9:30 PM. Call officer at 9876543210 immediately."
    val result = RiskEngine.analyze(text, source = "SMS Test")
    assertEquals(ScamCategory.ELECTRICITY_BILL, result.category)
    assertTrue(result.threatLevel == ThreatLevel.CRITICAL || result.threatLevel == ThreatLevel.HIGH_RISK)
    assertTrue(result.redFlags.isNotEmpty())
  }

  @Test
  fun testRiskEngine_detectsUpiPinTrap() {
    val text = "Scan this QR code and enter your UPI PIN to receive ₹5000 in your account."
    val result = RiskEngine.analyze(text, source = "UPI Test")
    assertEquals(ScamCategory.UPI_PAYMENT, result.category)
    assertTrue(result.threatLevel == ThreatLevel.HIGH_RISK || result.threatLevel == ThreatLevel.CRITICAL)
  }

  @Test
  fun testRiskEngine_safeBankAlert() {
    val text = "Dear Customer, your A/C ending XX4921 has been debited by Rs 450.00 on 17-Sep-26. Avail Bal: Rs 14,320.40. State Bank of India"
    val result = RiskEngine.analyze(text, source = "Bank Test")
    assertEquals(ThreatLevel.SAFE, result.threatLevel)
    assertFalse(result.riskScore > 30)
  }
}
