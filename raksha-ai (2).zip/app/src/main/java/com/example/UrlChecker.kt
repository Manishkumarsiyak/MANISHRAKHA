package com.example

// Re-export V5 advanced implementation to maintain full compatibility across namespaces
typealias UrlCheckResult = com.rakshaai.v5.UrlCheckResult
typealias UpiPaymentDetails = com.rakshaai.v5.UpiPaymentDetails
typealias UrlChecker = com.rakshaai.v5.UrlChecker
