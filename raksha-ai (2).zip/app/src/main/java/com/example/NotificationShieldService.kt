package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationCompat

class NotificationShieldService : NotificationListenerService() {

    companion object {
        const val CHANNEL_ID = "raksha_ai_security_alerts"
        const val CHANNEL_NAME = "Raksha AI Scam & Threat Alerts"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)

        if (sbn == null) return

        // Do not scan our own notifications to avoid infinite loops
        if (sbn.packageName == packageName) return

        // Verify if shield protection is toggled active
        if (!SecurityRepository.isShieldActive.value) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getString(Notification.EXTRA_TITLE) ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString() ?: ""

        val combinedContent = buildString {
            if (title.isNotBlank()) append(title).append(" - ")
            if (bigText.isNotBlank()) append(bigText) else append(text)
        }.trim()

        if (combinedContent.length < 5) return

        val appLabel = getAppNameFromPackage(sbn.packageName)
        val sourceLabel = "Alert from $appLabel"

        val analysis = RiskEngine.analyze(
            text = combinedContent,
            source = sourceLabel,
            sender = title.ifBlank { null },
            packageName = sbn.packageName
        )

        // Record scan into repository state for dashboard visibility
        SecurityRepository.recordScan(analysis)

        // If threat is detected as HIGH_RISK or CRITICAL, send immediate warning notification
        if (analysis.threatLevel == ThreatLevel.CRITICAL || analysis.threatLevel == ThreatLevel.HIGH_RISK) {
            triggerThreatAlert(analysis, appLabel)
        }
    }

    private fun triggerThreatAlert(analysis: AnalysisResult, sourceApp: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            analysis.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alertTitle = if (analysis.threatLevel == ThreatLevel.CRITICAL) {
            "🚨 CRITICAL SCAM: ${analysis.category.displayName}"
        } else {
            "⚠️ SUSPICIOUS ALERT: ${analysis.category.displayName}"
        }

        val originHeader = if (!analysis.origin.senderNameOrNumber.isNullOrBlank()) {
            "स्रोत: $sourceApp (${analysis.origin.senderNameOrNumber})"
        } else {
            "स्रोत: $sourceApp"
        }

        val alertBody = "$originHeader\n${analysis.recommendation.take(100)}..."

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle(alertTitle)
            .setContentText(alertBody)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$originHeader\n\n${analysis.recommendation}\n\nखतरा संदेश: \"${analysis.originalText}\""))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(Notification.DEFAULT_ALL)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(analysis.id.hashCode(), notification)
    }

    private fun getAppNameFromPackage(pkg: String): String {
        return try {
            val pm = packageManager
            val info = pm.getApplicationInfo(pkg, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            when {
                pkg.contains("whatsapp") -> "WhatsApp"
                pkg.contains("messaging") || pkg.contains("mms") -> "SMS Messenger"
                pkg.contains("telegram") -> "Telegram"
                pkg.contains("facebook") -> "Facebook"
                pkg.contains("instagram") -> "Instagram"
                else -> pkg.substringAfterLast('.')
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "High priority real-time alerts for phishing links, cyber fraud, and OTP scams."
                enableVibration(true)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
