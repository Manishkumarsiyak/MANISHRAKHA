package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AppRiskReport
import com.example.ThreatLevel
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDanger
import com.example.ui.theme.CyberDangerBg
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSafe
import com.example.ui.theme.CyberSafeBg
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberWarning
import com.example.ui.theme.CyberWarningBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Raksha AI V5 - App Security & Malware Auditor Tab
 * Allows users to inspect installed applications, identify banking trojan permission combinations,
 * and toggle background install interception.
 */
@Composable
fun AppDefenseTabContent(
    installedApps: List<AppRiskReport>,
    isScanning: Boolean,
    isInstallMonitorActive: Boolean,
    onScanApps: () -> Unit,
    onToggleInstallMonitor: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val criticalCount = installedApps.count { it.threatLevel == ThreatLevel.CRITICAL }
    val warningCount = installedApps.count { it.threatLevel == ThreatLevel.HIGH_RISK }
    val sideloadedCount = installedApps.count { it.isSideloaded }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Header & Overview
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(CyberPrimary.copy(alpha = 0.15f))
                                .border(1.dp, CyberPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Android,
                                contentDescription = "App Malware Scanner",
                                tint = CyberPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "App Malware & Trojan Shield",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }
                            Text(
                                text = "Detects dangerous permission combinations & sideloaded RATs",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Live Install Interceptor Switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberSurfaceVariant)
                            .border(1.dp, CyberBorder, RoundedCornerShape(10.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (isInstallMonitorActive) CyberSafe else CyberDanger)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "24x7 New App Install Interceptor",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Auto-scans packages when installed or updated",
                                    fontSize = 10.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        Switch(
                            checked = isInstallMonitorActive,
                            onCheckedChange = onToggleInstallMonitor,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyberBackground,
                                checkedTrackColor = CyberPrimary,
                                uncheckedThumbColor = TextMuted,
                                uncheckedTrackColor = CyberSurface
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Scan Now Button
                    Button(
                        onClick = onScanApps,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("scan_apps_button"),
                        enabled = !isScanning,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberPrimary,
                            contentColor = CyberBackground
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isScanning) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = CyberBackground,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Auditing Device Packages...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Scan",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Audit Installed Apps Now", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Metrics Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricPill(
                    title = "Audited Apps",
                    value = installedApps.size.toString(),
                    color = CyberPrimary,
                    modifier = Modifier.weight(1f)
                )
                MetricPill(
                    title = "Critical Trojans",
                    value = criticalCount.toString(),
                    color = if (criticalCount > 0) CyberDanger else CyberSafe,
                    modifier = Modifier.weight(1f)
                )
                MetricPill(
                    title = "Sideloaded",
                    value = sideloadedCount.toString(),
                    color = CyberWarning,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Education Card: Banking Trojan Signature
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant.copy(alpha = 0.6f)),
                border = BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Trojan Alert",
                            tint = CyberWarning,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "एंड्रॉइड ट्रोजन कैसे काम करते हैं? (Trojan Defense)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberWarning
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "खतरनाक ऐप्स अक्सर 'Accessibility Service' और 'Display Over Other Apps' की अनुमति मांगते हैं। इसके जरिए वे असली बैंकिंग ऐप के ऊपर नकली स्क्रीन बनाकर आपका पासवर्ड और SMS OTP चुराते हैं।",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Section Title
        item {
            Text(
                text = "Scanned Applications (${installedApps.size}):",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // Apps List
        if (installedApps.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No apps audited yet. Tap 'Audit Installed Apps Now'.",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                }
            }
        } else {
            items(installedApps, key = { it.packageName }) { appReport ->
                AppRiskCard(
                    report = appReport,
                    onOpenSettings = {
                        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.parse("package:${appReport.packageName}")
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        try {
                            context.startActivity(intent)
                        } catch (_: Exception) {
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun MetricPill(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Text(
                text = title,
                fontSize = 10.sp,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun AppRiskCard(
    report: AppRiskReport,
    onOpenSettings: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    val levelColor = when {
        report.isVerifiedEnterpriseApp -> CyberSafe
        report.threatLevel == ThreatLevel.CRITICAL -> CyberDanger
        report.threatLevel == ThreatLevel.HIGH_RISK -> CyberWarning
        report.threatLevel == ThreatLevel.LOW_RISK -> Color(0xFFFACC15)
        else -> CyberSafe
    }

    val levelBg = when {
        report.isVerifiedEnterpriseApp -> CyberSafeBg
        report.threatLevel == ThreatLevel.CRITICAL -> CyberDangerBg
        report.threatLevel == ThreatLevel.HIGH_RISK -> CyberWarningBg
        report.threatLevel == ThreatLevel.LOW_RISK -> Color(0xFF713F12)
        else -> CyberSafeBg
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded },
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(1.2.dp, if (report.isVerifiedEnterpriseApp) CyberSafe.copy(alpha = 0.6f) else if (report.riskScore >= 50) levelColor else CyberBorder),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: App name, risk score
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(levelBg)
                            .border(1.dp, levelColor, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (report.isVerifiedEnterpriseApp) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Verified Official App",
                                tint = CyberSafe,
                                modifier = Modifier.size(22.dp)
                            )
                        } else {
                            Text(
                                text = report.appName.take(1).uppercase(),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = levelColor
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = report.appName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (report.isVerifiedEnterpriseApp) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = CyberSafe,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                        Text(
                            text = "${report.packageName} • v${report.versionName}",
                            fontSize = 10.sp,
                            color = TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Risk Badge
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(levelBg)
                        .border(1.dp, levelColor, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (report.isVerifiedEnterpriseApp) "प्रमाणित 0/100" else "${report.riskScore}/100",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = levelColor,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Threat Badges Flow
            if (report.threatBadges.isNotEmpty()) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    report.threatBadges.take(3).forEach { badge ->
                        val isEnterpriseBadge = badge.contains("प्रमाणित") || badge.contains("Play Store")
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isEnterpriseBadge) CyberSafeBg else CyberSurfaceVariant)
                                .border(1.dp, if (isEnterpriseBadge) CyberSafe.copy(alpha = 0.5f) else CyberBorder, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = badge,
                                fontSize = 10.sp,
                                color = if (isEnterpriseBadge) CyberSafe else if (badge.contains("Trojan") || badge.contains("Abuser") || badge.contains("Stealer")) CyberDanger else TextSecondary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Expandable Details (Dangerous permissions & AI Reasoning)
            AnimatedVisibility(visible = expanded || report.threatLevel == ThreatLevel.CRITICAL) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    if (report.dangerousPermissions.isNotEmpty()) {
                        Text(
                            text = "Dangerous Permissions:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberWarning
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        report.dangerousPermissions.forEach { perm ->
                            Text(
                                text = "• $perm",
                                fontSize = 11.sp,
                                color = TextPrimary,
                                lineHeight = 15.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    // AI Explanation
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberSurfaceVariant)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = report.aiExplanation,
                            fontSize = 11.sp,
                            color = TextPrimary,
                            lineHeight = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Uninstall Action
                    OutlinedButton(
                        onClick = onOpenSettings,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(38.dp),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, if (report.riskScore >= 50) CyberDanger else CyberBorder),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (report.riskScore >= 50) CyberDanger else TextPrimary
                        )
                    ) {
                        Icon(
                            imageVector = if (report.riskScore >= 50) Icons.Default.DeleteOutline else Icons.Default.OpenInNew,
                            contentDescription = "Manage App",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (report.riskScore >= 50) "Uninstall / Revoke Permissions" else "Inspect in Settings",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}
