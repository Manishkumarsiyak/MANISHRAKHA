package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Assignment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.core.content.ContextCompat
import com.example.adaptive.GeminiConsentedFeature
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.adaptive.AdaptiveCyberAI
import com.example.adaptive.AdaptiveDefenseRule
import com.example.adaptive.EvolutionAuditLog
import com.example.adaptive.GeminiForensicReport
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDanger
import com.example.ui.theme.CyberDangerBg
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSafe
import com.example.ui.theme.CyberSafeBg
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberWarning
import com.example.ui.theme.CyberWarningBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * Screen 3: Pro-Level Adaptive Cyber AI & Autonomous Gemini Brain Studio
 * Features:
 * - Direct connection with Google Gemini 3.5 Flash
 * - Autonomous Self-Evolution Engine ("AI Khud Me Sudhar Kar Sake")
 * - Gemini Deep Cyber Forensic Copilot
 * - Live Threat Learning and Evolved Rule Management
 * - Self-Evolution History Timeline
 */
@Composable
fun AdaptiveAiScreen() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val evolvedRules by AdaptiveCyberAI.evolvedRules.collectAsState()
    val evolutionHistory by AdaptiveCyberAI.evolutionHistory.collectAsState()
    val proposedFeatures by AdaptiveCyberAI.proposedFeatures.collectAsState()
    val learningState by AdaptiveCyberAI.learningState.collectAsState()
    val connStatus by AdaptiveCyberAI.connectionStatus.collectAsState()

    var showApiKeyDialog by remember { mutableStateOf(false) }
    var forensicQueryText by remember { mutableStateOf("") }
    var forensicReport by remember { mutableStateOf<GeminiForensicReport?>(null) }
    var isAnalyzingForensic by remember { mutableStateOf(false) }

    var sampleInputText by remember { mutableStateOf("") }
    var userNoteText by remember { mutableStateOf("") }

    var featureRequirementText by remember { mutableStateOf("") }
    var isSynthesizingFeature by remember { mutableStateOf(false) }

    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPermission = granted
        if (granted) {
            Toast.makeText(context, "✅ नोटिफिकेशन सुरक्षा अनुमति सक्रिय!", Toast.LENGTH_SHORT).show()
        }
    }

    // Run connection test once on initial view
    LaunchedEffect(Unit) {
        AdaptiveCyberAI.testGeminiConnection(context)
    }

    val presetThreatExamples = listOf(
        "कूरियर पार्सल ड्रग्स अरेस्ट" to "Mumbai Customs Parcel #4829 contains illegal contraband. CBI Cyber crime officer demanding video statement on Skype to cancel arrest warrant.",
        "YouTube वीडियो लाइक जॉब" to "Earn ₹50 for every YouTube video like. Daily payout ₹3000 to ₹5000. Join our official Telegram VIP group t.me/vip_task_work and complete prepaid order.",
        "TRAI सिम डीएक्टिवेशन" to "Dear subscriber, your SIM card KYC is rejected by Telecom Regulatory Authority. Your outgoing calls will be stopped in 2 hours. Call 9811223344 immediately.",
        "बिजली बिल कनेक्शन कट" to "Dear consumer your electricity power will be disconnected tonight at 9:30 PM because previous month bill not updated. Call electricity officer 9876543210 immediately."
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Card: Gemini Pro Brain Dashboard
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimary.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(CyberPrimary.copy(alpha = 0.12f), Color.Transparent)
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(CyberPrimary.copy(alpha = 0.18f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Psychology,
                                        contentDescription = null,
                                        tint = CyberPrimary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "रक्षा AI - प्रो ब्रेन (Gemini 3.5 Flash)",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                    }
                                    Text(
                                        text = "ऑटोनॉमस आत्म-सुधार व साइबर रक्षा इंजन",
                                        fontSize = 11.sp,
                                        color = CyberPrimary
                                    )
                                }
                            }

                            // Key Setup Button
                            IconButton(
                                onClick = { showApiKeyDialog = true },
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(CyberSurfaceVariant)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Key,
                                    contentDescription = "Gemini Key Setup",
                                    tint = CyberPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Live Connection Pill
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (connStatus.isConnected) CyberSafeBg else CyberSurfaceVariant)
                                .border(1.dp, if (connStatus.isConnected) CyberSafe.copy(alpha = 0.5f) else CyberBorder, RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (connStatus.isConnected) CyberSafe else CyberWarning)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (connStatus.isConnected) "Google Gemini 3.5 Flash कनेक्टेड (${connStatus.latencyMs}ms)" else "ऑफलाइन न्यूरल मोड (डिफ़ॉल्ट)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (connStatus.isConnected) CyberSafe else TextSecondary
                                )
                            }
                            Text(
                                text = "सेटिंग्स",
                                fontSize = 10.sp,
                                color = CyberPrimary,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { showApiKeyDialog = true }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "यह AI जेमिनी 3.5 फ्लैश से सीधे जुड़कर नए फ्रॉड पैटर्न्स की समीक्षा करता है और अपनी रक्षा प्रणाली में खुद सुधार (Self-Evolution) करता है।",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Live AI Metrics
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AiMetricPill(
                                icon = Icons.Default.Shield,
                                label = "सक्रिय नियम",
                                value = "${evolvedRules.size} शील्ड",
                                color = CyberPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            AiMetricPill(
                                icon = Icons.Default.Refresh,
                                label = "आत्म-सुधार",
                                value = "${learningState.selfImprovementCount} चक्र",
                                color = CyberSafe,
                                modifier = Modifier.weight(1f)
                            )
                            AiMetricPill(
                                icon = Icons.Default.Speed,
                                label = "प्रतिक्रिया गति",
                                value = if (connStatus.latencyMs > 0) "${connStatus.latencyMs}ms" else "0.18s",
                                color = CyberWarning,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // PRO ACTION: RUN GEMINI SELF-EVOLUTION
        // ==========================================
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, CyberPrimary.copy(alpha = 0.7f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(CyberPrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(18.dp))
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "🚀 AI आत्म-सुधार चक्र (Self-Evolution)",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Gemini से जुड़कर AI अपनी सुरक्षा प्रणाली खुद सुधारेगा",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "बटन दबाते ही AI अपने मौजूदा नियमों की समीक्षा करेगा, 2026 के नए भारतीय साइबर खतरों की कमियों को पहचानेगा और तुरंत नए सुरक्षा नियम विकसित करेगा:",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            coroutineScope.launch {
                                try {
                                    val (auditLog, newRules) = AdaptiveCyberAI.runAutonomousSelfEvolution(context)
                                    Toast.makeText(
                                        context,
                                        "🎉 आत्म-सुधार सफल! ${newRules.size} नए सुरक्षा नियम जुड़े।",
                                        Toast.LENGTH_LONG
                                    ).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, "त्रुटि: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        enabled = !learningState.isLearning,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 12.dp)
                    ) {
                        if (learningState.isLearning) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = CyberBackground,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Gemini से आत्म-सुधार हो रहा है...",
                                fontSize = 12.sp,
                                color = CyberBackground,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Icon(Icons.Default.Psychology, contentDescription = null, tint = CyberBackground, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "⚡ जेमिनी से AI का आत्म-सुधार कराएं",
                                fontSize = 13.sp,
                                color = CyberBackground,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (learningState.isLearning) {
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp),
                            color = CyberPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = learningState.statusMessage,
                        fontSize = 11.sp,
                        color = if (learningState.isLearning) CyberPrimary else TextSecondary,
                        fontWeight = FontWeight.Medium
                    )

                    // Latest Evolution Audit Log snippet
                    val latestAudit = evolutionHistory.firstOrNull()
                    if (latestAudit != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberSurfaceVariant)
                                .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "📋 नवीनतम आत्म-सुधार रिपोर्ट:",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyberSafe
                                    )
                                    Text(
                                        text = if (latestAudit.isGeminiPowered) "Gemini 3.5" else "Neural Heuristic",
                                        fontSize = 10.sp,
                                        color = CyberPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = latestAudit.selfAnalysis,
                                    fontSize = 11.sp,
                                    color = TextPrimary,
                                    lineHeight = 15.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "पहचानी गई कमियां: " + latestAudit.blindspotsAddressed.joinToString(", "),
                                    fontSize = 10.sp,
                                    color = CyberWarning
                                )
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // PRO FEATURE 1: GEMINI CODE SYNTHESIZER & CONSENTED FEATURE STUDIO
        // (AI खुद Gemini से कोड पूछकर नया सुरक्षा फीचर तैयार करेगा और अनुमति द्वारा सक्रिय होगा)
        // ==========================================
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF38BDF8)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF38BDF8).copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "🛠️ Gemini कोड व फीचर स्टूडियो (अनुमति आधारित)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "AI जेमिनी से कोड पूछकर नए सुरक्षा फीचर्स खुद विकसित करेगा",
                                fontSize = 11.sp,
                                color = Color(0xFF38BDF8)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "आपको जो भी नया सुरक्षा फीचर चाहिए, उसे नीचे लिखें। रक्षा AI तुरंत Google Gemini 3.5 Flash से कोड लॉजिक तैयार कराएगा, जिसे आप अनुमति देकर सीधे इस ऐप में सक्रिय कर सकते हैं:",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Preset requirement chips
                    val featurePresets = listOf(
                        "व्हाट्सएप व फेसबुक फ्रॉड शील्ड" to "व्हाट्सएप और फेसबुक पर आने वाले फर्जी डिजिटल अरेस्ट वीडियो कॉल व पोंजी जॉब लिंक्स को ब्लॉक करने का कोड बनाएं",
                        "फोनपे रिवर्स UPI फ्रॉड ब्लॉकर" to "PhonePe पर 'पैसे प्राप्त करने के लिए UPI पिन डालें' वाले रिवर्स पेमेंट ट्रैप को रोकने का कोड बनाएं",
                        "अवैध लोन ऐप कांटेक्ट सुरक्षा" to "सैंडबॉक्स में चलने वाले फर्जी लोन ऐप्स द्वारा फोन कांटेक्ट व गैलरी चुराने से रोकने का कोड बनाएं",
                        "फर्जी सिम ब्लॉक TRAI कॉल डिटेक्टर" to "दूरसंचार विभाग (DoT/TRAI) के नाम पर सिम बंद होने की धमकी देने वाली फर्जी कॉल्स को ब्लॉक करने का कोड बनाएं"
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(featurePresets) { (chipTitle, reqText) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CyberSurfaceVariant)
                                    .border(1.dp, CyberBorder, RoundedCornerShape(6.dp))
                                    .clickable { featureRequirementText = reqText }
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = "+ $chipTitle",
                                    fontSize = 10.sp,
                                    color = Color(0xFF38BDF8),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = featureRequirementText,
                        onValueChange = { featureRequirementText = it },
                        label = { Text("जिस नए फीचर की जरूरत है, उसका विवरण यहाँ लिखें...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(84.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF38BDF8),
                            unfocusedBorderColor = CyberBorder
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (featureRequirementText.isBlank()) {
                                Toast.makeText(context, "कृपया पहले किसी फीचर का विवरण लिखें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            coroutineScope.launch {
                                isSynthesizingFeature = true
                                try {
                                    val feature = AdaptiveCyberAI.synthesizeFeatureFromGemini(context, featureRequirementText)
                                    Toast.makeText(context, "✨ जेमिनी ने '${feature.title}' का कोड तैयार किया!", Toast.LENGTH_LONG).show()
                                    featureRequirementText = ""
                                } catch (e: Exception) {
                                    Toast.makeText(context, "त्रुटि: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                } finally {
                                    isSynthesizingFeature = false
                                }
                            }
                        },
                        enabled = !isSynthesizingFeature,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 11.dp)
                    ) {
                        if (isSynthesizingFeature) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Gemini 3.5 से कोड व फीचर तैयार हो रहा है...", fontSize = 12.sp, color = Color.White)
                        } else {
                            Icon(Icons.Default.Build, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("🚀 Gemini से कोड पूछें व फीचर बनाएं", fontSize = 12.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Proposed Features List (Pending & Approved)
                    if (proposedFeatures.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "तैयार किए गए कोड फीचर्स (${proposedFeatures.size}):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        proposedFeatures.forEach { proposal ->
                            ConsentedFeatureCard(
                                proposal = proposal,
                                onApprove = {
                                    AdaptiveCyberAI.approveAndApplyFeature(proposal.id)
                                    Toast.makeText(context, "🎉 अनुमति स्वीकृत! नया कोड फीचर अब लाइव सक्रिय है।", Toast.LENGTH_LONG).show()
                                },
                                onDismiss = {
                                    AdaptiveCyberAI.rejectFeature(proposal.id)
                                },
                                onCopyCode = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Synthesized Code", proposal.synthesizedCode))
                                    Toast.makeText(context, "कोड क्लिपबोर्ड में कॉपी हो गया", Toast.LENGTH_SHORT).show()
                                }
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                    }
                }
            }
        }

        // ==========================================
        // PRO FEATURE 2: TRUSTED BIG TECH APP RECOGNITION (WhatsApp, PhonePe, Facebook Whitelist)
        // (बड़ी और विश्वसनीय कंपनियों के ऐप्स की सुरक्षा पहचान व इन-ऐप फ्रॉड शील्ड)
        // ==========================================
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberSafe.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(CyberSafe.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = CyberSafe,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "🛡️ प्रमाणित विश्वसनीय कंपनी शील्ड (Ecosystem Whitelist)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "WhatsApp, PhonePe, Facebook आदि को सुरक्षित पहचानता है",
                                fontSize = 11.sp,
                                color = CyberSafe
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "रक्षा AI का एडवांस्ड रिस्क इंजन दुनिया की प्रतिष्ठित और विश्वसनीय कंपनियों के आधिकारिक ऐप्स को 100% सुरक्षित (0/100 रिस्क) मानता है। इन ऐप्स के नाम पर होने वाले इन-ऐप फ्रॉड पर विशेष निगरानी रखी जाती है:",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val verifiedShowcase = listOf(
                        Triple("WhatsApp (Meta)", "संदेश व कॉलिंग: प्रमाणित सुरक्षित", "इन-ऐप फ्रॉड शील्ड: डिजिटल अरेस्ट फर्जी वीडियो कॉल व संदिग्ध APK फाइलों को लाइव रोकता है।"),
                        Triple("PhonePe (NPCI / RBI)", "UPI भुगतान: प्रमाणित सुरक्षित", "इन-ऐप फ्रॉड शील्ड: 'पैसे प्राप्त करने के लिए UPI पिन डालें' वाले रिवर्स फ्रॉड और फर्जी कैशबैक को रोकता है।"),
                        Triple("Facebook (Meta)", "सोशल मीडिया: प्रमाणित सुरक्षित", "इन-ऐप फ्रॉड शील्ड: फर्जी पार्ट-टाइम जॉब विज्ञापनों और पोंजी शेयर बाजार ग्रुप्स को पहचान कर रोकता है।"),
                        Triple("Google Pay (Google LLC)", "UPI व पेमेंट्स: प्रमाणित सुरक्षित", "इन-ऐप फ्रॉड शील्ड: अनजान लोगों द्वारा भेजे जाने वाले फर्जी रिफंड कलेक्ट रिक्वेस्ट को ब्लॉक करता है।")
                    )

                    verifiedShowcase.forEach { (appTitle, trustText, defenseText) ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(CyberSurfaceVariant)
                                .border(1.dp, CyberBorder, RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CyberSafe, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = appTitle, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    }
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(CyberSafeBg)
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(text = "सुरक्षित 0/100", fontSize = 10.sp, color = CyberSafe, fontWeight = FontWeight.Bold)
                                    }
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(text = trustText, fontSize = 10.sp, color = CyberSafe)
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(text = "🛡️ $defenseText", fontSize = 11.sp, color = TextSecondary, lineHeight = 15.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                }
            }
        }

        // ==========================================
        // PRO FEATURE 3: SECURITY PERMISSIONS & SYSTEM CONSENT HUB
        // (सुरक्षा अनुमतियां व सहमति केंद्र - यूजर से आवश्यक अनुमतियां मांगना व स्थिति दिखाना)
        // ==========================================
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberWarning.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(CyberWarning.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = CyberWarning,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "🔐 सुरक्षा अनुमतियां व सहमति केंद्र (Permissions Hub)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "व्हाट्सएप, फोनपे व एसएमएस रक्षा के लिए आवश्यक अनुमतियां",
                                fontSize = 11.sp,
                                color = CyberWarning
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "साइबर हमलों को लाइव रोकने के लिए ऐप को केवल आवश्यक सुरक्षा अनुमतियां चाहिए। आपकी स्पष्ट सहमति के बिना कोई भी कार्रवाई नहीं की जाती:",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Permission 1: POST_NOTIFICATIONS
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberSurfaceVariant)
                            .border(1.dp, if (hasNotificationPermission) CyberSafe.copy(alpha = 0.5f) else CyberBorder, RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = null,
                                        tint = if (hasNotificationPermission) CyberSafe else CyberWarning,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "लाइव फ्रॉड अलर्ट नोटिफिकेशन (POST_NOTIFICATIONS)",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                        Text(
                                            text = if (hasNotificationPermission) "✅ अनुमति सक्रिय है" else "⚠️ अनुमति की आवश्यकता है",
                                            fontSize = 10.sp,
                                            color = if (hasNotificationPermission) CyberSafe else CyberWarning,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "व्हाट्सएप या फोनपे पर कोई भी खतरनाक फिशिंग या कॉल आने पर तुरंत स्क्रीन पर पॉपअप चेतावनी दिखाने के लिए।",
                                fontSize = 11.sp,
                                color = TextSecondary,
                                lineHeight = 15.sp
                            )
                            if (!hasNotificationPermission) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        } else {
                                            Toast.makeText(context, "नोटिफिकेशन अनुमति डिफ़ॉल्ट रूप से सक्रिय है", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyberWarning),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    contentPadding = PaddingValues(vertical = 8.dp)
                                ) {
                                    Text(text = "🔔 अनुमति दें (Grant Notification Permission)", fontSize = 11.sp, color = CyberBackground, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Permission 2: NOTIFICATION_LISTENER_SERVICE
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberSurfaceVariant)
                            .border(1.dp, CyberBorder, RoundedCornerShape(10.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Shield, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "इनकमिंग संदेश व चैट शील्ड (Notification Access)",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                        Text(
                                            text = "व्हाट्सएप/फोनपे फ्रॉड मैसेज इंटरसेप्शन",
                                            fontSize = 10.sp,
                                            color = CyberPrimary
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "व्हाट्सएप, फोनपे और बैंक संदेशों में आने वाले फर्जी 'डिजिटल अरेस्ट', 'लॉटरी' और 'रिवर्स पिन' को वास्तविक समय में स्कैन करने हेतु।",
                                fontSize = 11.sp,
                                color = TextSecondary,
                                lineHeight = 15.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    try {
                                        val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                        }
                                        context.startActivity(intent)
                                    } catch (_: Exception) {
                                        Toast.makeText(context, "सिस्टम सेटिंग्स खोलें", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimary),
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                Icon(Icons.Default.OpenInNew, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "⚙️ एंड्रॉइड सेटिंग्स में नोटिफिकेशन एक्सेस खोलें", fontSize = 11.sp, color = CyberPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Privacy Assurance Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberSafeBg)
                            .border(1.dp, CyberSafe.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CyberSafe, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "🔒 100% स्थानीय प्राइवेसी: आपका कोई भी पासवर्ड, चैट या बैंकिंग विवरण किसी बाहरी सर्वर पर नहीं जाता। सभी परीक्षण ऑन-डिवाइस सैंडबॉक्स में होते हैं।",
                                fontSize = 10.sp,
                                color = CyberSafe,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }
        }

        // ==========================================
        // PRO ACTION: GEMINI DEEP FORENSIC COPILOT
        // ==========================================
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = CyberSafe, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "🔬 जेमिनी फॉरेन्सिक साइबर विशेषज्ञ (Deep Forensic Copilot)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "किसी भी संदिग्ध कॉल, घटना या मैसेज का जेमिनी से विस्तृत कानूनी और मनोवैज्ञानिक विश्लेषण कराएं:",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = forensicQueryText,
                        onValueChange = { forensicQueryText = it },
                        label = { Text("उदा. मुझे अनजान नंबर से वीडियो कॉल आई कि आपका पार्सल कस्टम्स में जब्त है...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(90.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberPrimary,
                            unfocusedBorderColor = CyberBorder
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (forensicQueryText.isBlank()) {
                                Toast.makeText(context, "कृपया पहले कोई घटना या प्रश्न लिखें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            coroutineScope.launch {
                                isAnalyzingForensic = true
                                try {
                                    val report = AdaptiveCyberAI.analyzeWithGeminiCopilot(context, forensicQueryText)
                                    forensicReport = report
                                } catch (e: Exception) {
                                    Toast.makeText(context, "त्रुटि: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                } finally {
                                    isAnalyzingForensic = false
                                }
                            }
                        },
                        enabled = !isAnalyzingForensic,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceVariant),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isAnalyzingForensic) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = CyberPrimary, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("जेमिनी गहन विश्लेषण कर रहा है...", fontSize = 12.sp, color = CyberPrimary)
                        } else {
                            Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("गहन फॉरेन्सिक जांच करें (Gemini Analysis)", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Forensic Result Card
                    val rep = forensicReport
                    if (rep != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(CyberDangerBg)
                                .border(1.dp, CyberDanger.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "🚨 खतरा: ${rep.threatType}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyberDanger
                                    )
                                    Text(
                                        text = "जोखिम: ${rep.threatScore}/100",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = CyberDanger
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "🧠 मनोवैज्ञानिक चाल: ${rep.psychologicalExploit}",
                                    fontSize = 11.sp,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "⚖️ भारतीय कानून धाराएं: ${rep.legalSection}",
                                    fontSize = 10.sp,
                                    color = CyberWarning
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                HorizontalDivider(color = CyberDanger.copy(alpha = 0.3f))
                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "🛡️ तत्काल बचाव निर्देश:",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyberSafe
                                )
                                Text(
                                    text = rep.tacticalAdviceHindi,
                                    fontSize = 11.sp,
                                    color = TextPrimary,
                                    lineHeight = 16.sp
                                )

                                val suggested = rep.suggestedRule
                                if (suggested != null) {
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            AdaptiveCyberAI.addDirectRule(suggested)
                                            Toast.makeText(context, "🎉 नया सुरक्षा नियम सक्रिय: ${suggested.title}", Toast.LENGTH_SHORT).show()
                                            forensicReport = null
                                            forensicQueryText = ""
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CyberSafe),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                        contentPadding = PaddingValues(vertical = 8.dp)
                                    ) {
                                        Icon(Icons.Default.Shield, contentDescription = null, tint = CyberBackground, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = "🛡️ इसे तुरंत सक्रिय रक्षा नियम बनाएं (+Add Rule)", fontSize = 11.sp, color = CyberBackground, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==========================================
        // SECTION 3: TEACH NEW THREAT MANUALLY
        // ==========================================
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lightbulb, contentDescription = null, tint = CyberWarning, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "AI को नया नमूना सिखाएं (Manual Sample Input)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "संदिग्ध मैसेज या फ्रॉड टेक्स्ट पेस्ट करें, AI इसका विश्लेषण कर तुरंत नया नियम बनाएगा:",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Preset Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(presetThreatExamples) { (label, text) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CyberSurfaceVariant)
                                    .border(1.dp, CyberBorder, RoundedCornerShape(6.dp))
                                    .clickable {
                                        sampleInputText = text
                                        userNoteText = label
                                    }
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Text(text = "+ $label", fontSize = 10.sp, color = CyberPrimary, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = sampleInputText,
                        onValueChange = { sampleInputText = it },
                        label = { Text("संदिग्ध मैसेज या फ्रॉड टेक्स्ट यहाँ पेस्ट करें...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(90.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberPrimary,
                            unfocusedBorderColor = CyberBorder
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = userNoteText,
                        onValueChange = { userNoteText = it },
                        label = { Text("नोट या संदर्भ (उदा. नया डिजिटल अरेस्ट वीडियो कॉल फ्रॉड)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberPrimary,
                            unfocusedBorderColor = CyberBorder
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (sampleInputText.isBlank()) {
                                Toast.makeText(context, "कृपया पहले कोई संदिग्ध टेक्स्ट दर्ज करें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            coroutineScope.launch {
                                try {
                                    val apiKey = AdaptiveCyberAI.getEffectiveApiKey(context)
                                    val rule = AdaptiveCyberAI.learnAndEvolveRule(
                                        threatText = sampleInputText,
                                        userNote = userNoteText.ifBlank { null },
                                        apiKey = apiKey
                                    )
                                    Toast.makeText(context, "🎉 AI ने नया सुरक्षा नियम विकसित किया: ${rule.title}", Toast.LENGTH_LONG).show()
                                    sampleInputText = ""
                                    userNoteText = ""
                                } catch (e: Exception) {
                                    Toast.makeText(context, "त्रुटि: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        enabled = !learningState.isLearning,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyberBackground, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "🧠 इस नमूने से सीखकर नया फीचर बनाएं",
                            fontSize = 12.sp,
                            color = CyberBackground,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // ==========================================
        // SECTION 4: ACTIVE EVOLVED RULES
        // ==========================================
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "AI द्वारा विकसित सक्रिय रक्षा नियम (${evolvedRules.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "लाइव इंजन में जुड़े",
                    fontSize = 11.sp,
                    color = CyberSafe,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        items(evolvedRules, key = { it.id }) { rule ->
            EvolvedRuleCard(
                rule = rule,
                onToggle = { AdaptiveCyberAI.toggleRule(rule.id) },
                onDelete = {
                    AdaptiveCyberAI.deleteRule(rule.id)
                    Toast.makeText(context, "${rule.title} हटाया गया", Toast.LENGTH_SHORT).show()
                }
            )
        }

        // ==========================================
        // SECTION 5: SELF-EVOLUTION HISTORY TIMELINE
        // ==========================================
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.History, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "AI आत्म-सुधार इतिहास (Self-Evolution Audit Timeline)",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        }

        items(evolutionHistory, key = { it.id }) { log ->
            EvolutionHistoryCard(log = log)
        }
    }

    // ==========================================
    // GEMINI API KEY & CONNECTION DIALOG
    // ==========================================
    if (showApiKeyDialog) {
        var keyInput by remember { mutableStateOf(AdaptiveCyberAI.getEffectiveApiKey(context) ?: "") }
        var isPinging by remember { mutableStateOf(false) }
        var pingResult by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showApiKeyDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Key, contentDescription = null, tint = CyberPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "Google Gemini 3.5 Flash सेटिंग", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
            },
            text = {
                Column {
                    Text(
                        text = "Google AI Studio से अपनी निःशुल्क API Key यहाँ जोड़ें। इससे AI की आत्म-सुधार और फॉरेन्सिक क्षमता प्रो-लेवल हो जाएगी:",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it },
                        label = { Text("Gemini API Key (AIza...)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberPrimary,
                            unfocusedBorderColor = CyberBorder
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = {
                                coroutineScope.launch {
                                    isPinging = true
                                    pingResult = null
                                    if (keyInput.isNotBlank()) {
                                        AdaptiveCyberAI.saveCustomApiKey(context, keyInput)
                                    }
                                    val test = AdaptiveCyberAI.testGeminiConnection(context)
                                    isPinging = false
                                    pingResult = test.message
                                }
                            },
                            enabled = !isPinging
                        ) {
                            if (isPinging) {
                                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = CyberPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("परीक्षण जारी...", fontSize = 11.sp, color = CyberPrimary)
                            } else {
                                Icon(Icons.Default.NetworkCheck, contentDescription = null, modifier = Modifier.size(14.dp), tint = CyberPrimary)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("लाइव पिंग टेस्ट", fontSize = 11.sp, color = CyberPrimary)
                            }
                        }

                        if (AdaptiveCyberAI.hasCustomApiKey(context)) {
                            TextButton(
                                onClick = {
                                    AdaptiveCyberAI.clearCustomApiKey(context)
                                    keyInput = ""
                                    coroutineScope.launch {
                                        AdaptiveCyberAI.testGeminiConnection(context)
                                    }
                                    Toast.makeText(context, "कस्टम की रीसेट की गई", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Text("डिफ़ॉल्ट रीसेट", fontSize = 11.sp, color = CyberDanger)
                            }
                        }
                    }

                    if (pingResult != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = pingResult!!,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (pingResult!!.contains("सफलतापूर्वक") || pingResult!!.contains("PONG")) CyberSafe else CyberDanger
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (keyInput.isNotBlank()) {
                            AdaptiveCyberAI.saveCustomApiKey(context, keyInput)
                        } else {
                            AdaptiveCyberAI.clearCustomApiKey(context)
                        }
                        coroutineScope.launch {
                            AdaptiveCyberAI.testGeminiConnection(context)
                        }
                        showApiKeyDialog = false
                        Toast.makeText(context, "सेटिंग्स सुरक्षित की गईं!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary)
                ) {
                    Text("सेव करें", color = CyberBackground, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiKeyDialog = false }) {
                    Text("रद्द करें", color = TextSecondary)
                }
            },
            containerColor = CyberSurface
        )
    }
}

@Composable
private fun AiMetricPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(CyberSurfaceVariant)
            .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.height(3.dp))
            Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = color)
            Text(text = label, fontSize = 9.sp, color = TextMuted)
        }
    }
}

@Composable
private fun EvolvedRuleCard(
    rule: AdaptiveDefenseRule,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (rule.isEnabled) CyberPrimary.copy(alpha = 0.4f) else CyberBorder
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (rule.isEnabled) CyberSafeBg else CyberDangerBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (rule.isEnabled) Icons.Default.Shield else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (rule.isEnabled) CyberSafe else CyberDanger,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = rule.title,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "स्रोत: ${rule.learnedFrom} • +${rule.riskWeight} जोखिम भार",
                            fontSize = 10.sp,
                            color = CyberPrimary
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = rule.isEnabled,
                        onCheckedChange = { onToggle() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberBackground,
                            checkedTrackColor = CyberPrimary,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = CyberSurfaceVariant
                        )
                    )
                    IconButton(onClick = onDelete, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = TextMuted, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = rule.description,
                fontSize = 11.sp,
                color = TextSecondary,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Keywords chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                rule.patternKeywords.take(4).forEach { kw ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(CyberSurfaceVariant)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = kw, fontSize = 9.sp, color = CyberWarning, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = CyberBorder.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.Top) {
                Text(
                    text = "🛡️ बचाव निर्देश: ",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberSafe
                )
                Text(
                    text = rule.actionPlan,
                    fontSize = 11.sp,
                    color = TextPrimary,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
private fun EvolutionHistoryCard(log: EvolutionAuditLog) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = log.title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberPrimary
                )
                Text(
                    text = if (log.isGeminiPowered) "Gemini 3.5 Flash" else "Neural Heuristic",
                    fontSize = 9.sp,
                    color = if (log.isGeminiPowered) CyberSafe else TextMuted,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = log.selfAnalysis,
                fontSize = 11.sp,
                color = TextSecondary,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                log.blindspotsAddressed.forEach { spot ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(CyberSurfaceVariant)
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(text = spot, fontSize = 9.sp, color = CyberWarning)
                    }
                }
            }
        }
    }
}

@Composable
private fun ConsentedFeatureCard(
    proposal: GeminiConsentedFeature,
    onApprove: () -> Unit,
    onDismiss: () -> Unit,
    onCopyCode: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceVariant),
        border = androidx.compose.foundation.BorderStroke(
            1.2.dp,
            if (proposal.isApprovedByUser) CyberSafe else Color(0xFF38BDF8).copy(alpha = 0.7f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (proposal.isApprovedByUser) Icons.Default.CheckCircle else Icons.Default.Code,
                        contentDescription = null,
                        tint = if (proposal.isApprovedByUser) CyberSafe else Color(0xFF38BDF8),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = proposal.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (proposal.isApprovedByUser) CyberSafeBg else Color(0xFF0C4A6E))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (proposal.isApprovedByUser) "अनुमति स्वीकृत ✅" else "अनुमति लंबित ⚠️",
                        fontSize = 10.sp,
                        color = if (proposal.isApprovedByUser) CyberSafe else Color(0xFF38BDF8),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = proposal.explanationHindi,
                fontSize = 11.sp,
                color = TextSecondary,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Code Snippet Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0B1120))
                    .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Kotlin Defense Logic (Gemini 3.5)",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            color = Color(0xFF94A3B8)
                        )
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Code",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { onCopyCode() }
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = proposal.synthesizedCode,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF38BDF8),
                        lineHeight = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Required Permissions
            Text(
                text = "आवश्यक सिस्टम अनुमतियां (Permissions Required):",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = CyberWarning
            )
            Spacer(modifier = Modifier.height(3.dp))
            proposal.requiredPermissions.forEach { perm ->
                Text(
                    text = "• $perm",
                    fontSize = 10.sp,
                    color = TextPrimary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = proposal.safetyAudit,
                fontSize = 10.sp,
                color = CyberSafe,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(6.dp))
            // Wisdom & Multi-Device Protection Badge
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF0F172A))
                    .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Psychology, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "🧠 विस्डम ऑडिट स्कोर: ${proposal.wisdomScore}/100",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF38BDF8)
                            )
                        }
                        Text(
                            text = "0% व्यर्थ कोड",
                            fontSize = 9.sp,
                            color = CyberSafe,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = proposal.wisdomAuditNote,
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "🛡️ उद्देश्य: ${proposal.deviceSafetyScope}",
                        fontSize = 10.sp,
                        color = CyberPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            if (!proposal.isApprovedByUser) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberSafe),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CyberBackground, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "✅ अनुमति दें व सक्रिय करें", fontSize = 11.sp, color = CyberBackground, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                        modifier = Modifier.weight(0.5f),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Text(text = "हटाएं", fontSize = 11.sp, color = TextMuted)
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(CyberSafeBg)
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "🎉 यह सुरक्षा फीचर रक्षा AI के एक्टिव शील्ड इंजन में लाइव काम कर रहा है!",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberSafe
                    )
                }
            }
        }
    }
}
