package com.example.ui.screens

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.SecurityRepository
import com.example.ui.AppDefenseTabContent
import com.example.ui.theme.CyberBackground

/**
 * Screen 4: Dedicated App Defense & Malware Quarantine Screen (ऐप सुरक्षा व मैलवेयर ऑडिट)
 */
@Composable
fun AppDefenseScreen() {
    val context = LocalContext.current
    val installedApps by SecurityRepository.installedApps.collectAsState()
    val isScanningApps by SecurityRepository.isScanningApps.collectAsState()
    val isInstallMonitorActive by SecurityRepository.isAppInstallMonitorActive.collectAsState()

    LaunchedEffect(Unit) {
        if (installedApps.isEmpty()) {
            SecurityRepository.scanInstalledApps(context)
        }
    }

    AppDefenseTabContent(
        installedApps = installedApps,
        isScanning = isScanningApps,
        isInstallMonitorActive = isInstallMonitorActive,
        onScanApps = { SecurityRepository.scanInstalledApps(context) },
        onToggleInstallMonitor = { SecurityRepository.setAppInstallMonitorActive(it) }
    )
}
