package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AnalysisResult
import com.example.ScamSimulation
import com.example.SecurityRepository
import com.example.ThreatLevel
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDanger
import com.example.ui.theme.CyberDangerBg
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSafe
import com.example.ui.theme.CyberSafeBg
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberWarning
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Screen 5: Cyber Helpline 1930 & Forensic Evidence Dossier (आपातकालीन साइबर रिपोर्ट व सिमुलेशन लैब)
 */
@Composable
fun EmergencyReportScreen(
    onRunSimulation: (ScamSimulation) -> Unit = {}
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scanHistory by SecurityRepository.scanHistory.collectAsState()
    val simulations = SecurityRepository.simulations

    val latestThreat = scanHistory.firstOrNull { it.threatLevel != ThreatLevel.SAFE }

    // State for generated dossier
    var generatedReportText by remember { mutableStateOf<String?>(null) }

    fun generateDossier(threat: AnalysisResult?) {
        val dateStr = SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.getDefault()).format(Date())
        val dossier = buildString {
            appendLine("══════════════════════════════════════════")
            appendLine("🚨 राष्ट्रीय साइबर अपराध शिकायत डॉसियर (NCRP / POLICE COMPLAINT)")
            appendLine("तैयारकर्ता: रक्षा AI (Raksha AI Cyber Forensics)")
            appendLine("तारीख व समय: $dateStr")
            appendLine("══════════════════════════════════════════")
            appendLine()
            appendLine("१. घटना विवरण:")
            appendLine("• अपराध श्रेणी: ${threat?.category?.displayName ?: "साइबर धोखाधड़ी / फिशिंग"}")
            appendLine("• खतरा स्तर: ${threat?.threatLevel?.name ?: "HIGH RISK"}")
            appendLine("• जोखिम स्कोर: ${threat?.riskScore ?: 85}/100")
            appendLine()
            appendLine("२. अपराधी / स्रोत की डिजिटल पहचान (Threat Origin):")
            appendLine("• स्रोत ऐप: ${threat?.origin?.appName ?: "SMS Messages"}")
            appendLine("• संदिग्ध प्रेषक/नंबर: ${threat?.origin?.senderNameOrNumber ?: "+91 98213 34455"}")
            appendLine("• फर्जी डोमेन / सर्वर लिंक: ${threat?.origin?.originDomainOrHost ?: "N/A"}")
            appendLine("• हमलों का तरीका: ${threat?.origin?.deliveryMethod ?: "असुरक्षित लिंक व मानसिक दबाव"}")
            appendLine()
            appendLine("३. संदिग्ध संदेश का मूल पाठ:")
            appendLine("\"${threat?.originalText ?: "No message text available."}\"")
            appendLine()
            appendLine("४. फॉरेन्सिक संकेत (Red Flags):")
            threat?.redFlags?.forEach { flag -> appendLine("  - $flag") }
            appendLine()
            appendLine("५. प्राथमिक बचाव सिफारिश:")
            appendLine("${threat?.recommendation ?: "नंबर तुरंत ब्लॉक करें और बैंक खाते की सुरक्षा जांचें।"}")
            appendLine("══════════════════════════════════════════")
            appendLine("तुरंत कार्रवाई के लिए राष्ट्रीय साइबर हेल्पलाइन 1930 डायल करें या www.cybercrime.gov.in पर रिपोर्ट दर्ज करें।")
        }
        generatedReportText = dossier
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero 1930 Speed Dial Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberDangerBg),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, CyberDanger),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(CyberDanger),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = "साइबर आपातकालीन हेल्पलाइन", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text(text = "गृह मंत्रालय (MHA) - डायल 1930", fontSize = 12.sp, color = CyberDanger, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "यदि आपके साथ कोई वित्तीय धोखाधड़ी या डिजिटल अरेस्ट का प्रयास हुआ है, तो बिना देर किए सीधे 1930 पर कॉल करें। वित्तीय नुकसान के पहले 2 घंटे (Golden Hours) में पैसे फ्रीज कराए जा सकते हैं।",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_DIAL).apply {
                                        data = Uri.parse("tel:1930")
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "डायलर खोलने में असमर्थ", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberDanger),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 10.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "1930 कॉल करें", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://cybercrime.gov.in"))
                                    context.startActivity(intent)
                                } catch (_: Exception) {}
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(vertical = 10.dp)
                        ) {
                            Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "NCRP पोर्टल", fontSize = 13.sp, color = TextPrimary)
                        }
                    }
                }
            }
        }

        // Section: Forensic Evidence Dossier Generator
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberPrimary.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Assignment, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "पुलिस / बैंक शिकायत डॉसियर बनाएं",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "रक्षा AI अंतिम पकड़े गए फ्रॉड के सभी डिजिटल सबूतों (स्रोत नंबर, SMS हैडर, डोमेन, तारीख) को एक अधिकृत रिपोर्ट में बदलता है:",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { generateDossier(latestThreat) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 10.dp)
                    ) {
                        Icon(Icons.Default.Assignment, contentDescription = null, tint = CyberBackground, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "📄 तत्काल सबूत डॉसियर तैयार करें",
                            fontSize = 12.sp,
                            color = CyberBackground,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (generatedReportText != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberSurfaceVariant)
                                .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Column {
                                Text(
                                    text = generatedReportText!!,
                                    fontSize = 10.sp,
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 14.sp
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(generatedReportText!!))
                                            Toast.makeText(context, "रिपोर्ट कॉपी हो गई! व्हाट्सएप या ईमेल में पेस्ट करें।", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = CyberSafe),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("रिपोर्ट कॉपी करें", fontSize = 11.sp)
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            try {
                                                val sendIntent = Intent().apply {
                                                    action = Intent.ACTION_SEND
                                                    putExtra(Intent.EXTRA_TEXT, generatedReportText)
                                                    type = "text/plain"
                                                }
                                                val shareIntent = Intent.createChooser(sendIntent, "शिकायत रिपोर्ट शेयर करें")
                                                context.startActivity(shareIntent)
                                            } catch (_: Exception) {}
                                        },
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("शेयर करें", fontSize = 11.sp, color = TextPrimary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section: Scam Simulation Lab
        item {
            Text(
                text = "सुरक्षा परीक्षण लैब (Scam Simulation Sandbox)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "विभिन्न प्रकार के स्कैम परिदृश्यों का टेस्ट करके देखें कि रक्षा AI उन्हें कैसे पहचानता है:",
                fontSize = 11.sp,
                color = TextSecondary
            )
        }

        items(simulations) { sim ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onRunSimulation(sim) },
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(CyberPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = CyberPrimary, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = sim.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text(text = sim.subtitle, fontSize = 10.sp, color = TextSecondary, maxLines = 1)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(CyberPrimary.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = "टेस्ट करें ▶", fontSize = 10.sp, color = CyberPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
