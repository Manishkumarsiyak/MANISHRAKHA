package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AnalysisResult
import com.example.BlacklistEntry
import com.example.BlacklistType
import com.example.ScamCategory
import com.example.SecurityRepository
import com.example.ThreatLevel
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDanger
import com.example.ui.theme.CyberDangerBg
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSafe
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberWarning
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Screen 2: Dedicated Threat Origin & Direct Block Hub (खतरा उद्गम व ब्लॉक सेंटर)
 * Directly answers user's core command:
 * "KHTRE KAHA SE AA RHE KONSI CHAT SMS YA NO KO BLOCK KRNA H OR KONSE APP KI"
 */
@Composable
fun ThreatOriginBlockScreen(
    onNavigateToAppDefense: () -> Unit = {}
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scanHistory by SecurityRepository.scanHistory.collectAsState()
    val blacklist by SecurityRepository.blacklist.collectAsState()

    var selectedCategoryIndex by remember { mutableIntStateOf(0) }
    val categories = listOf("सभी खतरे (All)", "फ़ोन नंबर (Calls)", "SMS प्रेषक", "चैट (WhatsApp)", "खतरनाक ऐप (APKs)", "सक्रिय ब्लॉकलिस्ट")

    var showAddDialog by remember { mutableStateOf(false) }

    // Aggregate threat origin targets from scan history and simulations
    val threatItems = remember(scanHistory) {
        scanHistory.filter { it.threatLevel != ThreatLevel.SAFE }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Block,
                                contentDescription = null,
                                tint = CyberDanger,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "खतरा स्रोत व ब्लॉक सेंटर",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = "पहचानें खतरा कहाँ से आया और 1-टैप में ब्लॉक या अनइंस्टॉल करें",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }

                    Button(
                        onClick = { showAddDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberDanger),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "नंबर ब्लॉक", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Metric Badges
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThreatSummaryStatBadge(
                        title = "सक्रिय ब्लॉक",
                        value = "${blacklist.size}",
                        color = CyberDanger,
                        modifier = Modifier.weight(1f)
                    )
                    ThreatSummaryStatBadge(
                        title = "पहचाने गए स्रोत",
                        value = "${threatItems.size}",
                        color = CyberWarning,
                        modifier = Modifier.weight(1f)
                    )
                    ThreatSummaryStatBadge(
                        title = "सुरक्षा स्थिति",
                        value = "100% ढाल",
                        color = CyberSafe,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Category Filter Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedCategoryIndex,
                containerColor = CyberSurfaceVariant,
                contentColor = CyberPrimary,
                edgePadding = 0.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.dp, CyberBorder, RoundedCornerShape(10.dp)),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedCategoryIndex]),
                        color = CyberPrimary
                    )
                }
            ) {
                categories.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedCategoryIndex == index,
                        onClick = { selectedCategoryIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = if (selectedCategoryIndex == index) FontWeight.Bold else FontWeight.Medium,
                                color = if (selectedCategoryIndex == index) CyberPrimary else TextSecondary
                            )
                        }
                    )
                }
            }
        }

        // Main Content based on Selected Tab
        if (selectedCategoryIndex == 5) {
            // View Active Blacklist
            if (blacklist.isEmpty()) {
                item {
                    EmptyBlocklistCard()
                }
            } else {
                items(blacklist, key = { it.id }) { entry ->
                    BlacklistCard(
                        entry = entry,
                        onUnblock = {
                            SecurityRepository.removeFromBlacklist(entry.id)
                            Toast.makeText(context, "${entry.target} को ब्लॉकलिस्ट से हटाया गया", Toast.LENGTH_SHORT).show()
                        },
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(entry.target))
                            Toast.makeText(context, "${entry.target} कॉपी किया गया", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        } else {
            // Show Detected Threats filtered by origin category
            val filteredThreats = when (selectedCategoryIndex) {
                1 -> threatItems.filter { it.origin.senderNameOrNumber?.contains(Regex("""\d{10}""")) == true }
                2 -> threatItems.filter { it.origin.channelType.contains("SMS") || it.origin.senderNameOrNumber?.contains("-") == true }
                3 -> threatItems.filter { it.origin.channelType.contains("WhatsApp") || it.origin.channelType.contains("चैट") }
                4 -> threatItems.filter { it.origin.deliveryMethod.contains("APK") || it.category == ScamCategory.MALWARE_APK }
                else -> threatItems
            }

            if (filteredThreats.isEmpty()) {
                item {
                    EmptyFilteredThreatCard()
                }
            } else {
                items(filteredThreats, key = { it.id }) { threat ->
                    ActionableThreatOriginCard(
                        threat = threat,
                        onBlockNumber = { number ->
                            SecurityRepository.addToBlacklist(
                                BlacklistEntry(
                                    type = BlacklistType.PHONE_NUMBER,
                                    target = number,
                                    sourceApp = threat.origin.appName,
                                    reason = threat.category.displayName,
                                    riskCategory = threat.category
                                )
                            )
                            // Trigger Android Phone Dialer / Block intent
                            try {
                                val intent = Intent(Intent.ACTION_DIAL).apply {
                                    data = Uri.parse("tel:${number.replace(" ", "")}")
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                            Toast.makeText(context, "$number को रक्षा AI ब्लॉकलिस्ट में जोड़ा गया", Toast.LENGTH_SHORT).show()
                        },
                        onBlockSender = { sender ->
                            SecurityRepository.addToBlacklist(
                                BlacklistEntry(
                                    type = BlacklistType.SMS_SENDER_ID,
                                    target = sender,
                                    sourceApp = threat.origin.appName,
                                    reason = threat.category.displayName,
                                    riskCategory = threat.category
                                )
                            )
                            Toast.makeText(context, "$sender को SMS ब्लॉकलिस्ट में जोड़ा गया", Toast.LENGTH_SHORT).show()
                        },
                        onUninstallApp = { pkg ->
                            try {
                                val intent = Intent(Intent.ACTION_DELETE).apply {
                                    data = Uri.parse("package:$pkg")
                                }
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "अनइंस्टॉल करने के लिए सेटिंग्स खोलें", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onBlockDomain = { domain ->
                            SecurityRepository.addToBlacklist(
                                BlacklistEntry(
                                    type = BlacklistType.PHISHING_DOMAIN,
                                    target = domain,
                                    sourceApp = "Web Browser",
                                    reason = "फिशिंग सर्वर लिंक",
                                    riskCategory = threat.category
                                )
                            )
                            Toast.makeText(context, "डोमेन $domain को ब्लॉकलिस्ट में जोड़ा गया", Toast.LENGTH_SHORT).show()
                        },
                        onCopyTarget = { text ->
                            clipboardManager.setText(AnnotatedString(text))
                            Toast.makeText(context, "कॉपी किया गया: $text", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    // Add Custom Block Dialog
    if (showAddDialog) {
        AddCustomBlockDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { target, type, reason ->
                SecurityRepository.addToBlacklist(
                    BlacklistEntry(
                        type = type,
                        target = target,
                        sourceApp = "उपयोगकर्ता द्वारा जोड़ा गया",
                        reason = reason,
                        riskCategory = ScamCategory.PHISHING_LINK
                    )
                )
                showAddDialog = false
                Toast.makeText(context, "$target ब्लॉकलिस्ट में जोड़ा गया", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
private fun ThreatSummaryStatBadge(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f)),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = color)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = title, fontSize = 10.sp, color = TextSecondary, maxLines = 1)
        }
    }
}

@Composable
private fun ActionableThreatOriginCard(
    threat: AnalysisResult,
    onBlockNumber: (String) -> Unit,
    onBlockSender: (String) -> Unit,
    onUninstallApp: (String) -> Unit,
    onBlockDomain: (String) -> Unit,
    onCopyTarget: (String) -> Unit
) {
    val origin = threat.origin
    val targetNumber = origin.senderNameOrNumber?.filter { it.isDigit() || it == '+' }
    val isPhone = targetNumber?.length in 10..13
    val isHeader = origin.senderNameOrNumber?.contains("-") == true

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberDanger.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Category and Source App
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(CyberDangerBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when {
                                isPhone -> Icons.Default.Phone
                                isHeader -> Icons.Default.Sms
                                origin.appName.contains("WhatsApp") -> Icons.Default.Chat
                                origin.deliveryMethod.contains("APK") -> Icons.Default.PhoneAndroid
                                else -> Icons.Default.Warning
                            },
                            contentDescription = null,
                            tint = CyberDanger,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = threat.category.displayName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "स्रोत: ${origin.appName} • ${origin.channelType}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CyberDangerBg)
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(text = "खतरा 🚨", fontSize = 10.sp, color = CyberDanger, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Forensic Target Box: EXACT Phone / SMS Header / URL to block
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberSurfaceVariant)
                    .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "🎯 ब्लॉक करने योग्य संदिग्ध पहचान:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberPrimary
                        )
                        IconButton(
                            onClick = {
                                val textToCopy = origin.senderNameOrNumber ?: origin.originDomainOrHost ?: origin.appName
                                onCopyTarget(textToCopy)
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextSecondary, modifier = Modifier.size(14.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = origin.senderNameOrNumber ?: "अज्ञात प्रेषक",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberDanger,
                        fontFamily = FontFamily.Monospace
                    )

                    if (!origin.originDomainOrHost.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "लिंक सर्वर: ${origin.originDomainOrHost}",
                            fontSize = 11.sp,
                            color = CyberWarning,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "हमले का तरीका: ${origin.deliveryMethod}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons: Real System Intents to block or uninstall
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (isPhone && !targetNumber.isNullOrBlank()) {
                    Button(
                        onClick = { onBlockNumber(targetNumber) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberDanger),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "नंबर ब्लॉक करें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (isHeader && !origin.senderNameOrNumber.isNullOrBlank()) {
                    Button(
                        onClick = { onBlockSender(origin.senderNameOrNumber) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberWarning),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "SMS हैडर ब्लॉक", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (!origin.originDomainOrHost.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = { onBlockDomain(origin.originDomainOrHost) },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "डोमेन ब्लॉक", fontSize = 11.sp, color = TextPrimary)
                    }
                }

                if (origin.deliveryMethod.contains("APK") && !origin.appPackage.isNullOrBlank()) {
                    Button(
                        onClick = { onUninstallApp(origin.appPackage) },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberDanger),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "ऐप अनइंस्टॉल", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun BlacklistCard(
    entry: BlacklistEntry,
    onUnblock: () -> Unit,
    onCopy: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(entry.type.badgeColorHex).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (entry.type) {
                            BlacklistType.PHONE_NUMBER -> Icons.Default.Phone
                            BlacklistType.SMS_SENDER_ID -> Icons.Default.Sms
                            BlacklistType.CHAT_CONTACT -> Icons.Default.Chat
                            BlacklistType.MALICIOUS_APP -> Icons.Default.PhoneAndroid
                            BlacklistType.PHISHING_DOMAIN -> Icons.Default.Public
                        },
                        contentDescription = null,
                        tint = Color(entry.type.badgeColorHex),
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = entry.target,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(entry.type.badgeColorHex).copy(alpha = 0.2f))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = entry.type.displayName,
                                fontSize = 9.sp,
                                color = Color(entry.type.badgeColorHex),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${entry.reason} • ${entry.sourceApp}",
                        fontSize = 11.sp,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row {
                IconButton(onClick = onCopy, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onUnblock, modifier = Modifier.size(30.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Unblock", tint = CyberDanger, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
private fun EmptyBlocklistCard() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CyberSurface)
            .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Check, contentDescription = null, tint = CyberSafe, modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "कोई सक्रिय ब्लैकलिस्ट प्रविष्टि नहीं है", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = "ऊपर '+ नंबर ब्लॉक' बटन से किसी भी नंबर या SMS हैडर को जोड़ें।", fontSize = 11.sp, color = TextSecondary)
        }
    }
}

@Composable
private fun EmptyFilteredThreatCard() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CyberSurface)
            .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Security, contentDescription = null, tint = CyberSafe, modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "इस श्रेणी में कोई सक्रिय खतरा नहीं मिला", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(text = "रक्षा AI रडार सभी इनकमिंग संदेशों की निगरानी कर रहा है।", fontSize = 11.sp, color = TextSecondary)
        }
    }
}

@Composable
private fun AddCustomBlockDialog(
    onDismiss: () -> Unit,
    onAdd: (target: String, type: BlacklistType, reason: String) -> Unit
) {
    var targetText by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(BlacklistType.PHONE_NUMBER) }
    var reasonText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = "नया खतरा ब्लॉकलिस्ट में जोड़ें", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "प्रकार चुनें:", fontSize = 12.sp, color = TextSecondary)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    listOf(BlacklistType.PHONE_NUMBER, BlacklistType.SMS_SENDER_ID, BlacklistType.PHISHING_DOMAIN).forEach { type ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (selectedType == type) CyberPrimary else CyberSurfaceVariant)
                                .clickable { selectedType = type }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = type.displayName,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedType == type) CyberBackground else TextPrimary
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = targetText,
                    onValueChange = { targetText = it },
                    label = { Text(when (selectedType) {
                        BlacklistType.PHONE_NUMBER -> "फ़ोन नंबर दर्ज करें (+91...)"
                        BlacklistType.SMS_SENDER_ID -> "SMS हैडर (उदा. DM-INPOST)"
                        else -> "वेबसाइट डोमेन (उदा. sbi-kyc.xyz)"
                    }) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberPrimary,
                        unfocusedBorderColor = CyberBorder
                    )
                )

                OutlinedTextField(
                    value = reasonText,
                    onValueChange = { reasonText = it },
                    label = { Text("कारण / नोट (उदा. बिजली बिल फ्रॉड कॉलर)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberPrimary,
                        unfocusedBorderColor = CyberBorder
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (targetText.isNotBlank()) {
                        onAdd(targetText.trim(), selectedType, reasonText.ifBlank { "संदिग्ध स्कैमर" })
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyberDanger)
            ) {
                Text("ब्लॉक करें")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("रद्द करें")
            }
        },
        containerColor = CyberSurface
    )
}
