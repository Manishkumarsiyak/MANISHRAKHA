package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryStd
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Laptop
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Watch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.AnalysisResult
import com.example.RiskEngine
import com.example.SecurityRepository
import com.example.ThreatLevel
import com.example.hardware.ConnectedDeviceDefense
import com.example.hardware.DeviceHealthEngine
import com.example.hardware.DeviceHealthSnapshot
import com.example.ui.AnalysisResultCard
import com.example.ui.StatCard
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDanger
import com.example.ui.theme.CyberDangerBg
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSafe
import com.example.ui.theme.CyberSafeBg
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberWarning
import com.example.ui.theme.CyberWarningBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Screen 1: Real-time Radar & Threat Command Center (शील्ड रडार व कमांड सेंटर)
 */
@Composable
fun ShieldRadarScreen(
    onNavigateToBlockHub: () -> Unit = {}
) {
    val context = LocalContext.current
    val isShieldActive by SecurityRepository.isShieldActive.collectAsState()
    val stats by SecurityRepository.stats.collectAsState()
    val blacklist by SecurityRepository.blacklist.collectAsState()
    val scanHistory by SecurityRepository.scanHistory.collectAsState()
    val healthSnapshot by DeviceHealthEngine.snapshot.collectAsState()

    LaunchedEffect(Unit) {
        DeviceHealthEngine.refreshTelemetry(context)
    }

    var inputText by remember { mutableStateOf("") }
    var currentAnalysis by remember { mutableStateOf<AnalysisResult?>(null) }
    val displayedAnalysis = currentAnalysis ?: scanHistory.firstOrNull()

    val presetQuickScans = listOf(
        "बिजली बिल कटने की धमकी" to "Dear consumer electricity power disconnected tonight at 9:30 PM call 9876543210 immediately",
        "SBI फर्जी PAN KYC APK" to "SBI Alert: A/C suspended due to pending PAN KYC. Download net banking update: http://sbi-kyc-update.xyz/SbiKycNet.apk",
        "पार्सल कूरियर री-डिलीवरी" to "IndiaPost: Your package #IN8271 delivery address missing. Update address to avoid return: http://indiapost-update.cam/pay",
        "प्रमाणित बैंक क्रेडिट (सुरक्षित)" to "A/C XXXX1204 credited by Rs 15,000.00 on 17-Sep-26 via NEFT. Avail Bal Rs 37,400.00."
    )

    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Radar Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = BorderStroke(1.dp, if (isShieldActive) CyberSafe.copy(alpha = 0.5f) else CyberDanger.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    (if (isShieldActive) CyberSafe else CyberDanger).copy(alpha = 0.08f),
                                    Color.Transparent
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .scale(if (isShieldActive) pulseScale else 1f)
                                        .clip(CircleShape)
                                        .background((if (isShieldActive) CyberSafe else CyberDanger).copy(alpha = 0.15f))
                                        .border(1.5.dp, if (isShieldActive) CyberSafe else CyberDanger, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (isShieldActive) Icons.Default.Radar else Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = if (isShieldActive) CyberSafe else CyberDanger,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "रक्षा AI रडार शील्ड",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = if (isShieldActive) "रीयल-टाइम सुरक्षा सक्रिय • 24/7 रडार" else "शील्ड रोकी गई है • डिवाइस असुरक्षित",
                                        fontSize = 11.sp,
                                        color = if (isShieldActive) CyberSafe else CyberDanger,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            // Active Toggle
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(if (isShieldActive) CyberSafeBg else CyberDangerBg)
                                    .border(1.dp, if (isShieldActive) CyberSafe else CyberDanger, RoundedCornerShape(20.dp))
                                    .clickable { SecurityRepository.setShieldActive(!isShieldActive) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = if (isShieldActive) "सक्रिय (ON)" else "निष्क्रिय (OFF)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isShieldActive) CyberSafe else CyberDanger
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Live Stats Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            StatCard(
                                title = "खतरे ब्लॉक किए",
                                value = stats.threatsBlocked.toString(),
                                color = CyberDanger,
                                modifier = Modifier.weight(1f)
                            )
                            StatCard(
                                title = "सक्रिय ब्लैकलिस्ट",
                                value = blacklist.size.toString(),
                                color = CyberWarning,
                                modifier = Modifier.weight(1f)
                            )
                            StatCard(
                                title = "सुरक्षित संदेश",
                                value = stats.safeMessages.toString(),
                                color = CyberSafe,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Phone Hardware, Battery & Storage Health + Multi-Device Protection Mission
        item {
            DeviceHealthAndDefenseCard(
                snapshot = healthSnapshot,
                onRefresh = { DeviceHealthEngine.refreshTelemetry(context) }
            )
        }

        // Quick Scan Input Box
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "संदिग्ध SMS, WhatsApp लिंक या नंबर जांचें",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Row {
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val item = clipboard.primaryClip?.getItemAt(0)
                                    item?.text?.let { inputText = it.toString() }
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.ContentPaste, contentDescription = "Paste", tint = CyberPrimary, modifier = Modifier.size(18.dp))
                            }
                            if (inputText.isNotEmpty()) {
                                IconButton(
                                    onClick = {
                                        inputText = ""
                                        currentAnalysis = null
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        placeholder = {
                            Text(
                                text = "संदिग्ध संदेश, टेलीग्राम टास्क, एपीके लिंक या फोन नंबर यहाँ पेस्ट करें...",
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberPrimary,
                            unfocusedBorderColor = CyberBorder
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Preset Chips
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(presetQuickScans) { (label, text) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CyberSurfaceVariant)
                                    .border(1.dp, CyberBorder, RoundedCornerShape(6.dp))
                                    .clickable {
                                        inputText = text
                                        val res = RiskEngine.analyze(text, source = "रडार टेस्ट: $label")
                                        currentAnalysis = res
                                        SecurityRepository.recordScan(res)
                                    }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(text = label, fontSize = 10.sp, color = CyberPrimary, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                val res = RiskEngine.analyze(inputText, source = "रडार डायरेक्ट स्कैन")
                                currentAnalysis = res
                                SecurityRepository.recordScan(res)
                            }
                        },
                        enabled = inputText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = CyberPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(vertical = 12.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = CyberBackground, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "🛡️ रडार से खतरा व स्रोत स्कैन करें",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberBackground
                        )
                    }
                }
            }
        }

        // Analysis Result Card (if any active or historical scan available)
        if (displayedAnalysis != null) {
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🛡️ नवीनतम रडार खतरा विश्लेषण (Active Threat Intel):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        if (currentAnalysis != null) {
                            Text(
                                text = "रीसेट करें",
                                fontSize = 11.sp,
                                color = CyberPrimary,
                                modifier = Modifier
                                    .clickable { currentAnalysis = null }
                                    .padding(4.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    AnalysisResultCard(analysis = displayedAnalysis)

                    // Quick Jump to Block Hub if threat found
                    if (displayedAnalysis.threatLevel != ThreatLevel.SAFE) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = onNavigateToBlockHub,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberDanger),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth(),
                            contentPadding = PaddingValues(vertical = 10.dp)
                        ) {
                            Icon(Icons.Default.Block, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "🛑 इस स्रोत / नंबर को ब्लॉक सेंटर में देखें", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DeviceHealthAndDefenseCard(
    snapshot: DeviceHealthSnapshot,
    onRefresh: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF0F766E).copy(alpha = 0.3f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = Color(0xFF2DD4BF),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "📱 फोन हार्डवेयर, बैटरी व स्टोरेज स्थिति",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "ऑप्टिमाइज्ड लाइटवेट कोड • न्यूनतम MB • शून्य बैटरी अपव्यय",
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }
                IconButton(onClick = onRefresh, modifier = Modifier.size(28.dp)) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "रिफ्रेश",
                        tint = CyberPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3 Hardware Metrics Cards in Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Battery Metric
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberSurfaceVariant)
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
                        .padding(8.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (snapshot.battery.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryStd,
                                contentDescription = null,
                                tint = if (snapshot.battery.percentage > 20) CyberSafe else CyberWarning,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${snapshot.battery.percentage}%",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (snapshot.battery.isCharging) "चार्ज हो रहा है ⚡" else "बैटरी पर",
                            fontSize = 9.sp,
                            color = if (snapshot.battery.isCharging) CyberSafe else TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "${snapshot.battery.temperatureCelsius}°C • ${snapshot.battery.health}",
                            fontSize = 8.sp,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "खपत: < 0.04%/दिन",
                            fontSize = 8.sp,
                            color = CyberPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Storage Metric
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberSurfaceVariant)
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
                        .padding(8.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Storage,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${snapshot.storage.availableGB}GB",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "खाली / ${snapshot.storage.totalGB}GB",
                            fontSize = 9.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = "उपयोग: ${snapshot.storage.usedPercentage}%",
                            fontSize = 8.sp,
                            color = if (snapshot.storage.isStorageLow) CyberDanger else TextMuted
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "रक्षा AI: ~11 MB",
                            fontSize = 8.sp,
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // RAM Metric
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberSurfaceVariant)
                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(10.dp))
                        .padding(8.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Memory,
                                contentDescription = null,
                                tint = Color(0xFFA78BFA),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${snapshot.memory.availableRamGB}GB",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "रैम फ्री / ${snapshot.memory.totalRamGB}GB",
                            fontSize = 9.sp,
                            color = TextSecondary
                        )
                        Text(
                            text = "लोड: ${snapshot.memory.ramUsedPercentage}%",
                            fontSize = 8.sp,
                            color = TextMuted
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "रैम उपयोग: ~14 MB",
                            fontSize = 8.sp,
                            color = Color(0xFFA78BFA),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Solemn Defense Mission Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F172A))
                    .border(1.dp, Color(0xFF0284C7).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = Color(0xFF38BDF8),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "अखंड सुरक्षा प्रतिज्ञा (Solemn Mission)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF38BDF8)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "सर्वोच्च उद्देश्य: आपकी और आपके सभी डिवाइसेस की 24x7 अभेद्य सुरक्षा। सिस्टम में कोई भी अनर्गल या व्यर्थ कोड नहीं जोड़ा जाएगा—केवल शुद्ध, न्यूनतम व प्रभावी रक्षा नियम शामिल होंगे।",
                            fontSize = 10.sp,
                            color = TextPrimary,
                            lineHeight = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Connected Devices Ecosystem Perimeter
            Text(
                text = "🛡️ सभी कनेक्टेड डिवाइसेस सुरक्षा दायरा (All Devices Protected):",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                snapshot.connectedDevices.forEach { dev ->
                    ConnectedDeviceRow(device = dev)
                }
            }
        }
    }
}

@Composable
private fun ConnectedDeviceRow(device: ConnectedDeviceDefense) {
    val icon = when (device.deviceType) {
        "TABLET_PC" -> Icons.Default.Laptop
        "WEARABLE" -> Icons.Default.Watch
        else -> Icons.Default.Smartphone
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF131C2E))
            .border(1.dp, Color(0xFF1E293B), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 7.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = CyberPrimary,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = device.deviceName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Text(
                        text = device.statusHindi,
                        fontSize = 9.sp,
                        color = TextSecondary
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = CyberSafe,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "सुरक्षित",
                    fontSize = 10.sp,
                    color = CyberSafe,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
