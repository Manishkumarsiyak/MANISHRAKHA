package com.example.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.AnalysisResult
import com.example.RiskEngine
import com.example.ScamCategory
import com.example.ScamSimulation
import com.example.SecurityRepository
import com.example.ThreatLevel
import com.example.ThreatOrigin
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDanger
import com.example.ui.theme.CyberDangerBg
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSafe
import com.example.ui.theme.CyberSafeBg
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberWarning
import com.example.ui.theme.CyberWarningBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun SecurityDashboardScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val history by SecurityRepository.scanHistory.collectAsStateWithLifecycle()
    val stats by SecurityRepository.stats.collectAsStateWithLifecycle()
    val isShieldActive by SecurityRepository.isShieldActive.collectAsStateWithLifecycle()
    val installedApps by SecurityRepository.installedApps.collectAsStateWithLifecycle()
    val isScanningApps by SecurityRepository.isScanningApps.collectAsStateWithLifecycle()
    val isAppInstallMonitorActive by SecurityRepository.isAppInstallMonitorActive.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) }
    var inputText by remember { mutableStateOf("") }
    var currentAnalysis by remember { mutableStateOf<AnalysisResult?>(null) }
    var isNotificationAccessGranted by remember { mutableStateOf(false) }

    // Check system notification listener status
    LaunchedEffect(Unit) {
        val enabledPackages = NotificationManagerCompat.getEnabledListenerPackages(context)
        isNotificationAccessGranted = enabledPackages.contains(context.packageName)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
    ) {
        // App Header
        AppTopHeader(
            isShieldActive = isShieldActive,
            isNotificationAccessGranted = isNotificationAccessGranted,
            onToggleShield = {
                SecurityRepository.setShieldActive(!isShieldActive)
                Toast.makeText(
                    context,
                    if (!isShieldActive) "Raksha AI Shield Enabled" else "Raksha AI Shield Paused",
                    Toast.LENGTH_SHORT
                ).show()
            },
            onRequestAccess = {
                val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                try {
                    context.startActivity(intent)
                } catch (_: Exception) {
                    Toast.makeText(context, "Open Settings -> Notification Access", Toast.LENGTH_SHORT).show()
                }
            }
        )

        // Navigation Tabs
        PrimaryTabRow(
            selectedTabIndex = selectedTab,
            containerColor = CyberSurface,
            contentColor = CyberPrimary,
            indicator = {
                TabRowDefaults.PrimaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(selectedTab),
                    color = CyberPrimary,
                    width = 32.dp
                )
            },
            divider = { HorizontalDivider(color = CyberBorder) }
        ) {
            val tabs = listOf("Scanner", "App Defense", "Simulations", "Threat Log", "Helpline 1930")
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    modifier = Modifier.testTag("tab_$index"),
                    text = {
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTab == index) CyberPrimary else TextSecondary,
                            maxLines = 1
                        )
                    }
                )
            }
        }

        // Tab Contents
        when (selectedTab) {
            0 -> ScannerTabContent(
                inputText = inputText,
                onInputTextChange = { inputText = it },
                currentAnalysis = currentAnalysis,
                onAnalyze = {
                    if (inputText.isNotBlank()) {
                        val res = RiskEngine.analyze(inputText, source = "Manual Scan")
                        currentAnalysis = res
                        SecurityRepository.recordScan(res)
                    }
                },
                onClear = {
                    inputText = ""
                    currentAnalysis = null
                },
                onPaste = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val item = clipboard.primaryClip?.getItemAt(0)
                    item?.text?.let {
                        inputText = it.toString()
                    }
                },
                onSelectPreset = { sample ->
                    inputText = sample
                    val res = RiskEngine.analyze(sample, source = "Simulation")
                    currentAnalysis = res
                    SecurityRepository.recordScan(res)
                },
                stats = stats
            )
            1 -> AppDefenseTabContent(
                installedApps = installedApps,
                isScanning = isScanningApps,
                isInstallMonitorActive = isAppInstallMonitorActive,
                onScanApps = {
                    SecurityRepository.scanInstalledApps(context)
                },
                onToggleInstallMonitor = { active ->
                    SecurityRepository.setAppInstallMonitorActive(active)
                }
            )
            2 -> SimulationsTabContent(
                simulations = SecurityRepository.simulations,
                onRunSimulation = { simulation ->
                    inputText = simulation.sampleText
                    val res = RiskEngine.analyze(simulation.sampleText, source = "Simulation: ${simulation.title}")
                    currentAnalysis = res
                    SecurityRepository.recordScan(res)
                    selectedTab = 0 // jump to scanner to view result
                }
            )
            3 -> ThreatLogTabContent(
                history = history,
                onClearHistory = {
                    SecurityRepository.clearHistory()
                    Toast.makeText(context, "Log cleared", Toast.LENGTH_SHORT).show()
                },
                onDeleteItem = { id ->
                    SecurityRepository.removeHistoryItem(id)
                }
            )
            4 -> HelplineTabContent()
        }
    }
}

@Composable
private fun AppTopHeader(
    isShieldActive: Boolean,
    isNotificationAccessGranted: Boolean,
    onToggleShield: () -> Unit,
    onRequestAccess: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(CyberPrimary.copy(alpha = 0.2f), CyberSurfaceVariant)
                                )
                            )
                            .border(1.5.dp, CyberPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Shield Icon",
                            tint = CyberPrimary,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Raksha AI",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CyberPrimary.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "V5 PRO",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = CyberPrimary
                                )
                            }
                        }
                        Text(
                            text = "Real-Time Cyber Fraud & Scam Shield",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                // Shield Toggle Button
                Box(
                    modifier = Modifier
                        .scale(if (isShieldActive) pulseScale else 1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isShieldActive) CyberSafeBg else CyberDangerBg)
                        .border(
                            1.dp,
                            if (isShieldActive) CyberSafe else CyberDanger,
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { onToggleShield() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("shield_toggle_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (isShieldActive) CyberSafe else CyberDanger)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isShieldActive) "ACTIVE" else "PAUSED",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isShieldActive) CyberSafe else CyberDanger
                        )
                    }
                }
            }

            // Notification Access Reminder Banner
            if (!isNotificationAccessGranted) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberWarningBg.copy(alpha = 0.5f))
                        .border(1.dp, CyberWarning.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                        .clickable { onRequestAccess() }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.NotificationsActive,
                        contentDescription = "Notification Access",
                        tint = CyberWarning,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Live SMS & App Shield Needs Permission",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Tap to enable Notification Access for automated scam detection",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Open Settings",
                        tint = CyberWarning,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ScannerTabContent(
    inputText: String,
    onInputTextChange: (String) -> Unit,
    currentAnalysis: AnalysisResult?,
    onAnalyze: () -> Unit,
    onClear: () -> Unit,
    onPaste: () -> Unit,
    onSelectPreset: (String) -> Unit,
    stats: com.example.SecurityStats
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Stats Overview Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Threats Blocked",
                    value = stats.threatsBlocked.toString(),
                    color = CyberDanger,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Links Checked",
                    value = stats.urlsScreened.toString(),
                    color = CyberPrimary,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Safe Messages",
                    value = stats.safeMessages.toString(),
                    color = CyberSafe,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Input Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Analyze SMS, Link or WhatsApp Alert",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Row {
                            IconButton(
                                onClick = onPaste,
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("paste_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentPaste,
                                    contentDescription = "Paste text",
                                    tint = CyberPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            if (inputText.isNotEmpty()) {
                                IconButton(
                                    onClick = onClear,
                                    modifier = Modifier
                                        .size(32.dp)
                                        .testTag("clear_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Clear text",
                                        tint = TextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = onInputTextChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("message_input_field"),
                        placeholder = {
                            Text(
                                text = "Paste suspicious message, SMS, link, electricity bill threat, or lottery message here...",
                                fontSize = 13.sp,
                                color = TextMuted
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberPrimary,
                            unfocusedBorderColor = CyberBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = CyberPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = onAnalyze,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("scan_button"),
                        enabled = inputText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberPrimary,
                            contentColor = CyberBackground,
                            disabledContainerColor = CyberSurfaceVariant,
                            disabledContentColor = TextMuted
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Scan",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Scan for Cyber Threats & Phishing",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        // Quick Scam Test Chips
        item {
            Column {
                Text(
                    text = "Quick Scam Simulator Presets:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextSecondary,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        QuickPresetChip(
                            label = "⚡ Electricity Disconnection",
                            onClick = {
                                onSelectPreset(
                                    "Dear consumer, your electricity power will be disconnected tonight at 9:30 PM because previous bill not updated. Call officer at 9811223344 immediately."
                                )
                            }
                        )
                    }
                    item {
                        QuickPresetChip(
                            label = "🏦 SBI Fake KYC APK",
                            onClick = {
                                onSelectPreset(
                                    "Dear SBI user, your net banking account is blocked. Update PAN KYC within 24 hours to prevent closure: http://sbi-kyc-update.xyz/app.apk"
                                )
                            }
                        )
                    }
                    item {
                        QuickPresetChip(
                            label = "💰 Part-Time Job Telegram",
                            onClick = {
                                onSelectPreset(
                                    "Work from home! Earn ₹3000 to ₹5000 daily by simply liking YouTube videos. Join official Telegram group: http://bit.ly/daily-task-payout"
                                )
                            }
                        )
                    }
                    item {
                        QuickPresetChip(
                            label = "💳 UPI Reverse PIN Trap",
                            onClick = {
                                onSelectPreset(
                                    "Buyer sent ₹12,000 for item. Enter your 6-digit UPI PIN to receive money in your account."
                                )
                            }
                        )
                    }
                    item {
                        QuickPresetChip(
                            label = "✅ Safe Bank SMS",
                            onClick = {
                                onSelectPreset(
                                    "Dear Customer, your A/C ending XX2104 has been debited by Rs 250.00 on 17-Sep-26 at Coffee Shop. Avail Bal: Rs 15,200.00. - HDFC Bank"
                                )
                            }
                        )
                    }
                }
            }
        }

        // Analysis Result View
        if (currentAnalysis != null) {
            item {
                AnalysisResultCard(
                    analysis = currentAnalysis,
                    onCopy = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText(
                            "Raksha AI Report",
                            "Raksha AI Alert: Threat Level ${currentAnalysis.threatLevel} (${currentAnalysis.category.displayName})\n${currentAnalysis.recommendation}\n\nOriginal Text: ${currentAnalysis.originalText}"
                        )
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Report copied to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    onShare = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "⚠️ Raksha AI Cyber Threat Warning!\nCategory: ${currentAnalysis.category.displayName}\nThreat Score: ${currentAnalysis.riskScore}/100\nRecommendation: ${currentAnalysis.recommendation}\n\nStay protected with Raksha AI."
                            )
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Cyber Alert"))
                    }
                )
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(1.dp, CyberBorder),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun QuickPresetChip(
    label: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(CyberSurfaceVariant)
            .border(1.dp, CyberBorder, RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = TextPrimary,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun AnalysisResultCard(
    analysis: AnalysisResult,
    onCopy: () -> Unit = {},
    onShare: () -> Unit = {}
) {
    val levelColor = when (analysis.threatLevel) {
        ThreatLevel.CRITICAL -> CyberDanger
        ThreatLevel.HIGH_RISK -> CyberWarning
        ThreatLevel.LOW_RISK -> Color(0xFFFACC15)
        ThreatLevel.SAFE -> CyberSafe
    }

    val levelBg = when (analysis.threatLevel) {
        ThreatLevel.CRITICAL -> CyberDangerBg
        ThreatLevel.HIGH_RISK -> CyberWarningBg
        ThreatLevel.LOW_RISK -> Color(0xFF713F12)
        ThreatLevel.SAFE -> CyberSafeBg
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("analysis_result_card"),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        border = BorderStroke(1.5.dp, levelColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Level & Category Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when (analysis.threatLevel) {
                            ThreatLevel.CRITICAL, ThreatLevel.HIGH_RISK -> Icons.Default.Warning
                            ThreatLevel.LOW_RISK -> Icons.Default.HelpOutline
                            ThreatLevel.SAFE -> Icons.Default.VerifiedUser
                        },
                        contentDescription = "Threat Icon",
                        tint = levelColor,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = analysis.threatLevel.name.replace('_', ' '),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = levelColor
                        )
                        Text(
                            text = analysis.category.displayName,
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }

                // Score Gauge Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(levelBg)
                        .border(1.dp, levelColor, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "RISK: ${analysis.riskScore}/100",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = levelColor,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Bar
            LinearProgressIndicator(
                progress = { (analysis.riskScore / 100f).coerceIn(0.05f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = levelColor,
                trackColor = CyberSurfaceVariant
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Authoritative Recommendation Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyberSurfaceVariant)
                    .border(1.dp, CyberBorder, RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Security Advice",
                            tint = CyberPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Raksha AI Protective Guidance",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = analysis.recommendation,
                        fontSize = 13.sp,
                        color = TextPrimary,
                        lineHeight = 18.sp
                    )
                }
            }

            // AI Deep Reasoning (Hindi + English)
            if (analysis.aiReasoning.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberSurfaceVariant.copy(alpha = 0.7f))
                        .border(1.dp, CyberBorder, RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "AI Reasoning",
                                tint = CyberPrimary,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "🛡️ रक्षा AI साइबर फॉरेन्सिक विश्लेषण",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = analysis.aiReasoning,
                            fontSize = 12.sp,
                            color = TextSecondary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // Threat Origin Forensic Box (खतरा कहाँ से आया?)
            Spacer(modifier = Modifier.height(10.dp))
            ThreatOriginCard(origin = analysis.origin, threatLevel = analysis.threatLevel)

            // Red Flags List
            if (analysis.redFlags.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Identified Threat Flags (${analysis.redFlags.size}):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                analysis.redFlags.forEach { flag ->
                    Row(
                        modifier = Modifier.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = "• ",
                            color = levelColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = flag,
                            fontSize = 12.sp,
                            color = TextPrimary,
                            lineHeight = 16.sp
                        )
                    }
                }
            }

            // Detected Links Breakdown
            if (analysis.detectedUrls.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Embedded URLs Screened (${analysis.detectedUrls.size}):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                analysis.detectedUrls.forEach { urlResult ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberSurfaceVariant.copy(alpha = 0.5f))
                            .border(
                                1.dp,
                                if (urlResult.isSuspicious) CyberDanger.copy(alpha = 0.6f) else CyberBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .padding(8.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Link,
                                    contentDescription = "Link",
                                    tint = if (urlResult.isSuspicious) CyberDanger else CyberPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = urlResult.domain,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (urlResult.isSuspicious) CyberDanger else TextPrimary
                                )
                            }
                            Text(
                                text = urlResult.url,
                                fontSize = 11.sp,
                                color = TextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons (Copy Report / Share Alert)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onCopy,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, CyberBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Copy Report", fontSize = 12.sp)
                }

                Button(
                    onClick = onShare,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = levelColor,
                        contentColor = Color.White
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Share Warning", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ThreatOriginCard(
    origin: ThreatOrigin,
    threatLevel: ThreatLevel,
    modifier: Modifier = Modifier
) {
    val levelColor = when (threatLevel) {
        ThreatLevel.CRITICAL -> CyberDanger
        ThreatLevel.HIGH_RISK -> CyberWarning
        ThreatLevel.LOW_RISK -> Color(0xFFFACC15)
        ThreatLevel.SAFE -> CyberSafe
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CyberSurfaceVariant.copy(alpha = 0.9f))
            .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.GpsFixed,
                        contentDescription = "Threat Origin",
                        tint = CyberPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "खतरा कहाँ से आया? (Threat Origin)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberPrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(CyberSurface)
                        .border(1.dp, CyberBorder, RoundedCornerShape(6.dp))
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = origin.channelType,
                        fontSize = 10.sp,
                        color = TextSecondary,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 1. Source App
            OriginDetailRow(
                icon = Icons.Default.PhoneAndroid,
                label = "स्रोत ऐप (App)",
                value = origin.appName,
                subValue = origin.appPackage
            )

            // 2. Sender / Number
            if (!origin.senderNameOrNumber.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                OriginDetailRow(
                    icon = Icons.Default.Person,
                    label = "भेजने वाला (Sender)",
                    value = origin.senderNameOrNumber,
                    valueColor = if (threatLevel != ThreatLevel.SAFE) levelColor else TextPrimary
                )
            }

            // 3. Domain / Host Server
            if (!origin.originDomainOrHost.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                OriginDetailRow(
                    icon = Icons.Default.Public,
                    label = "होस्ट सर्वर (Domain/URL)",
                    value = origin.originDomainOrHost,
                    valueColor = if (threatLevel != ThreatLevel.SAFE) CyberDanger else CyberPrimary
                )
            }

            // 4. Delivery Method
            Spacer(modifier = Modifier.height(6.dp))
            OriginDetailRow(
                icon = Icons.Default.ReportProblem,
                label = "डिलीवरी का तरीका",
                value = origin.deliveryMethod
            )

            // 5. Actionable Prevention Tip
            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = CyberBorder.copy(alpha = 0.6f))
            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.Top) {
                Text(
                    text = "🛡️ स्रोत से बचाव: ",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberSafe
                )
                Text(
                    text = origin.preventionTip,
                    fontSize = 11.sp,
                    color = TextPrimary,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
private fun OriginDetailRow(
    icon: ImageVector,
    label: String,
    value: String,
    subValue: String? = null,
    valueColor: Color = TextPrimary
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = TextSecondary,
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "$label: ",
            fontSize = 11.sp,
            color = TextSecondary,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value,
            fontSize = 11.sp,
            color = valueColor,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
        if (!subValue.isNullOrBlank()) {
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "($subValue)",
                fontSize = 10.sp,
                color = TextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SimulationsTabContent(
    simulations: List<ScamSimulation>,
    onRunSimulation: (ScamSimulation) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = "Simulations",
                        tint = CyberPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Interactive Cyber Fraud Lab",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Test Raksha AI's threat engine against the most prevalent real-world scams.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        items(simulations) { sim ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = sim.title,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = sim.subtitle,
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(CyberSurfaceVariant)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = sim.category.displayName,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberSurfaceVariant.copy(alpha = 0.5f))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "\"${sim.sampleText}\"",
                            fontSize = 12.sp,
                            color = TextMuted,
                            lineHeight = 16.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { onRunSimulation(sim) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberPrimary.copy(alpha = 0.15f),
                            contentColor = CyberPrimary
                        ),
                        border = BorderStroke(1.dp, CyberPrimary.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Test",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Test in Risk Engine",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ThreatLogTabContent(
    history: List<AnalysisResult>,
    onClearHistory: () -> Unit,
    onDeleteItem: (String) -> Unit
) {
    var filterLevel by remember { mutableStateOf<ThreatLevel?>(null) }
    var expandedItemId by remember { mutableStateOf<String?>(null) }

    val filteredHistory = remember(history, filterLevel) {
        if (filterLevel == null) history else history.filter { it.threatLevel == filterLevel }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Controls Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "History & Intercepted Logs (${history.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                if (history.isNotEmpty()) {
                    IconButton(
                        onClick = onClearHistory,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "Clear History",
                            tint = CyberDanger,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // Filter Chips Row
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = filterLevel == null,
                        onClick = { filterLevel = null },
                        label = { Text("All", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyberPrimary,
                            selectedLabelColor = CyberBackground,
                            containerColor = CyberSurface,
                            labelColor = TextSecondary
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = filterLevel == ThreatLevel.CRITICAL,
                        onClick = { filterLevel = if (filterLevel == ThreatLevel.CRITICAL) null else ThreatLevel.CRITICAL },
                        label = { Text("Critical", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyberDanger,
                            selectedLabelColor = Color.White,
                            containerColor = CyberSurface,
                            labelColor = TextSecondary
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = filterLevel == ThreatLevel.HIGH_RISK,
                        onClick = { filterLevel = if (filterLevel == ThreatLevel.HIGH_RISK) null else ThreatLevel.HIGH_RISK },
                        label = { Text("High Risk", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyberWarning,
                            selectedLabelColor = Color.White,
                            containerColor = CyberSurface,
                            labelColor = TextSecondary
                        )
                    )
                }
                item {
                    FilterChip(
                        selected = filterLevel == ThreatLevel.SAFE,
                        onClick = { filterLevel = if (filterLevel == ThreatLevel.SAFE) null else ThreatLevel.SAFE },
                        label = { Text("Safe", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyberSafe,
                            selectedLabelColor = Color.White,
                            containerColor = CyberSurface,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
        }

        // Threat Origin Explainer Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(CyberSurfaceVariant.copy(alpha = 0.7f))
                    .border(1.dp, CyberBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.Top) {
                    Icon(
                        imageVector = Icons.Default.GpsFixed,
                        contentDescription = "Origin Guide",
                        tint = CyberPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "खतरा कहाँ से आया? (Threat Origin Tracker)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "रक्षा AI हर खतरे के स्रोत (ऐप, प्रेषक नंबर, SMS हैडर व सर्वर) को ट्रैक करता है। नीचे किसी भी लॉग पर टैप करके पूरा स्रोत विश्लेषण देखें।",
                            fontSize = 11.sp,
                            color = TextSecondary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        if (filteredHistory.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Empty History",
                            tint = TextMuted,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No scan logs found in this category",
                            fontSize = 13.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        } else {
            items(filteredHistory, key = { it.id }) { item ->
                val isExpanded = expandedItemId == item.id
                val levelColor = when (item.threatLevel) {
                    ThreatLevel.CRITICAL -> CyberDanger
                    ThreatLevel.HIGH_RISK -> CyberWarning
                    ThreatLevel.LOW_RISK -> Color(0xFFFACC15)
                    ThreatLevel.SAFE -> CyberSafe
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandedItemId = if (isExpanded) null else item.id },
                    colors = CardDefaults.cardColors(containerColor = CyberSurface),
                    border = BorderStroke(1.dp, if (isExpanded) levelColor else CyberBorder),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(levelColor)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = item.category.displayName,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(CyberSurfaceVariant)
                                                .border(1.dp, CyberBorder, RoundedCornerShape(4.dp))
                                                .padding(horizontal = 5.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = item.origin.appName,
                                                fontSize = 10.sp,
                                                color = CyberPrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = formatTimestamp(item.timestamp),
                                            fontSize = 10.sp,
                                            color = TextSecondary
                                        )
                                    }
                                    if (!item.origin.senderNameOrNumber.isNullOrBlank()) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "स्रोत: ${item.origin.senderNameOrNumber}",
                                            fontSize = 11.sp,
                                            color = if (item.threatLevel != ThreatLevel.SAFE) levelColor else TextSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(levelColor.copy(alpha = 0.15f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "${item.riskScore}%",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = levelColor
                                    )
                                }
                                IconButton(
                                    onClick = { onDeleteItem(item.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Clear,
                                        contentDescription = "Delete",
                                        tint = TextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = item.originalText,
                            fontSize = 12.sp,
                            color = TextMuted,
                            maxLines = if (isExpanded) Int.MAX_VALUE else 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        AnimatedVisibility(
                            visible = isExpanded,
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut()
                        ) {
                            Column(modifier = Modifier.padding(top = 8.dp)) {
                                HorizontalDivider(color = CyberBorder, modifier = Modifier.padding(vertical = 6.dp))

                                // Threat Origin Detailed Card in History
                                ThreatOriginCard(origin = item.origin, threatLevel = item.threatLevel)
                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = "Protection Advice: ${item.recommendation}",
                                    fontSize = 12.sp,
                                    color = TextPrimary,
                                    lineHeight = 16.sp
                                )
                                if (item.redFlags.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Red Flags:",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = levelColor
                                    )
                                    item.redFlags.forEach { flag ->
                                        Text(
                                            text = "• $flag",
                                            fontSize = 11.sp,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HelplineTabContent() {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Emergency 1930 Call Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberDangerBg),
                border = BorderStroke(1.5.dp, CyberDanger),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(CyberDanger.copy(alpha = 0.2f))
                                .border(1.5.dp, CyberDanger, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = "Emergency Call",
                                tint = CyberDanger,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Cyber Fraud Emergency: 1930",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextPrimary
                            )
                            Text(
                                text = "National Cyber Crime Reporting Helpline",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "If money has been deducted from your account, call 1930 within the 'Golden Hour' to freeze fraudulent transactions before scammers withdraw funds.",
                        fontSize = 12.sp,
                        color = TextPrimary,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                data = Uri.parse("tel:1930")
                            }
                            context.startActivity(intent)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberDanger,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = "Dial 1930",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Direct Dial 1930 Helpline",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Golden Hour Protocol Checklist
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🚨 The 4-Step 'Golden Hour' Emergency Action",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    ActionChecklistItem(
                        number = "1",
                        title = "Block Cards & UPI Immediately",
                        description = "Open your official banking app or netbanking and disable all UPI, debit card, and international transaction permissions."
                    )
                    ActionChecklistItem(
                        number = "2",
                        title = "Dial 1930 & Visit cybercrime.gov.in",
                        description = "Lodge a complaint on India's National Cyber Crime Reporting Portal (cybercrime.gov.in). Keep transaction IDs and SMS ready."
                    )
                    ActionChecklistItem(
                        number = "3",
                        title = "Airplane Mode if APK was installed",
                        description = "If you downloaded an APK file, immediately turn on Airplane Mode and disconnect Wi-Fi to stop remote control tools."
                    )
                    ActionChecklistItem(
                        number = "4",
                        title = "Report to Chakshu & Sanchar Saathi",
                        description = "Report fraudulent SMS sender numbers and WhatsApp scam accounts at sancharsaathi.gov.in to blacklist the scammers."
                    )
                }
            }
        }

        // Golden Rules of Cyber Safety
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                border = BorderStroke(1.dp, CyberBorder),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🛡️ Raksha AI Golden Rules of Cyber Defense",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberSafe
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    GoldenRuleItem(
                        icon = Icons.Default.Shield,
                        rule = "UPI PIN is ONLY for Paying",
                        detail = "You NEVER enter a UPI PIN or scan a QR code to receive money. If someone asks for PIN to send you money, it is 100% fraud."
                    )
                    GoldenRuleItem(
                        icon = Icons.Default.Shield,
                        rule = "Banks Never Send APK Files",
                        detail = "No legitimate bank or government agency asks you to install an APK file from a link or WhatsApp to update KYC."
                    )
                    GoldenRuleItem(
                        icon = Icons.Default.Shield,
                        rule = "Discoms Don't Text Personal Numbers",
                        detail = "Electricity departments send automated bills, never messages asking to call private 10-digit mobile numbers."
                    )
                    GoldenRuleItem(
                        icon = Icons.Default.Shield,
                        rule = "'Digital Arrest' Does Not Exist",
                        detail = "Police, CBI, ED, or Customs never arrest people over Skype or video calls. It is completely fraudulent."
                    )
                }
            }
        }
    }
}

@Composable
private fun ActionChecklistItem(
    number: String,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier.padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(CyberPrimary.copy(alpha = 0.15f))
                .border(1.dp, CyberPrimary, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = CyberPrimary
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = description,
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
private fun GoldenRuleItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    rule: String,
    detail: String
) {
    Row(
        modifier = Modifier.padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = CyberSafe,
            modifier = Modifier
                .size(20.dp)
                .padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = rule,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = detail,
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 16.sp
            )
        }
    }
}

private fun formatTimestamp(time: Long): String {
    val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    return sdf.format(Date(time))
}
