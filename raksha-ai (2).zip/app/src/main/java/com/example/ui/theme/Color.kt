package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBackground = Color(0xFF090E17)
val CyberSurface = Color(0xFF111A2E)
val CyberSurfaceVariant = Color(0xFF17233D)
val CyberBorder = Color(0xFF22355A)

val CyberPrimary = Color(0xFF00F0FF)
val CyberPrimaryDark = Color(0xFF0284C7)
val CyberSecondary = Color(0xFF38BDF8)
val CyberAccent = Color(0xFF6366F1)

val CyberSafe = Color(0xFF10B981)
val CyberSafeBg = Color(0xFF064E3B)
val CyberWarning = Color(0xFFF59E0B)
val CyberWarningBg = Color(0xFF78350F)
val CyberDanger = Color(0xFFEF4444)
val CyberDangerBg = Color(0xFF7F1D1D)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

