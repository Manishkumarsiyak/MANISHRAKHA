package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import com.example.RiskEngine
import com.example.SecurityRepository
import com.example.adaptive.AdaptiveCyberAI
import com.example.ui.screens.AdaptiveAiScreen
import com.example.ui.screens.AppDefenseScreen
import com.example.ui.screens.EmergencyReportScreen
import com.example.ui.screens.ShieldRadarScreen
import com.example.ui.screens.ThreatOriginBlockScreen
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberDanger
import com.example.ui.theme.CyberDangerBg
import com.example.ui.theme.CyberPrimary
import com.example.ui.theme.CyberSafe
import com.example.ui.theme.CyberSafeBg
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.CyberWarning
import com.example.ui.theme.CyberWarningBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

sealed class SuperNavDestination(
    val routeIndex: Int,
    val title: String,
    val icon: ImageVector,
    val hindiLabel: String
) {
    object Radar : SuperNavDestination(0, "Radar", Icons.Default.Radar, "रडार")
    object BlockHub : SuperNavDestination(1, "Block Hub", Icons.Default.Block, "ब्लॉक हब")
    object AdaptiveAi : SuperNavDestination(2, "Adaptive AI", Icons.Default.Psychology, "AI कोर")
    object AppDefense : SuperNavDestination(3, "App Defense", Icons.Default.Security, "ऐप रक्षा")
    object Emergency : SuperNavDestination(4, "Helpline", Icons.Default.Call, "1930")
}

/**
 * Super App Navigation Shell
 * Provides 5 distinct screens, unified Cyber HUD, Notification Listener Monitor, and Emergency 1930 speed dial.
 */
@Composable
fun SuperAppNavigation(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedScreenIndex by remember { mutableIntStateOf(0) }

    val isShieldActive by SecurityRepository.isShieldActive.collectAsState()
    val blacklist by SecurityRepository.blacklist.collectAsState()
    val evolvedRules by AdaptiveCyberAI.evolvedRules.collectAsState()
    val scanHistory by SecurityRepository.scanHistory.collectAsState()

    var isNotificationAccessGranted by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val enabledListeners = NotificationManagerCompat.getEnabledListenerPackages(context)
        isNotificationAccessGranted = enabledListeners.contains(context.packageName)
    }

    val destinations = listOf(
        SuperNavDestination.Radar,
        SuperNavDestination.BlockHub,
        SuperNavDestination.AdaptiveAi,
        SuperNavDestination.AppDefense,
        SuperNavDestination.Emergency
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = CyberBackground,
        topBar = {
            SuperAppTopBar(
                isShieldActive = isShieldActive,
                onToggleShield = { SecurityRepository.setShieldActive(!isShieldActive) },
                onDialEmergency = {
                    try {
                        val intent = Intent(Intent.ACTION_DIAL).apply {
                            data = Uri.parse("tel:1930")
                        }
                        context.startActivity(intent)
                    } catch (_: Exception) {}
                },
                isNotificationAccessGranted = isNotificationAccessGranted,
                onRequestNotificationAccess = {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    context.startActivity(intent)
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CyberSurface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .border(1.dp, CyberBorder, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            ) {
                destinations.forEach { dest ->
                    val isSelected = selectedScreenIndex == dest.routeIndex
                    val badgeCount = when (dest.routeIndex) {
                        1 -> blacklist.size
                        2 -> evolvedRules.size
                        else -> 0
                    }

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedScreenIndex = dest.routeIndex },
                        icon = {
                            if (badgeCount > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(
                                            containerColor = if (dest.routeIndex == 1) CyberDanger else CyberPrimary,
                                            contentColor = Color.White
                                        ) {
                                            Text(badgeCount.toString(), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = dest.icon,
                                        contentDescription = dest.title,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = dest.icon,
                                    contentDescription = dest.title,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        },
                        label = {
                            Text(
                                text = dest.hindiLabel,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CyberBackground,
                            selectedTextColor = CyberPrimary,
                            indicatorColor = CyberPrimary,
                            unselectedIconColor = TextSecondary,
                            unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = selectedScreenIndex,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { targetIndex ->
                when (targetIndex) {
                    0 -> ShieldRadarScreen(
                        onNavigateToBlockHub = { selectedScreenIndex = 1 }
                    )
                    1 -> ThreatOriginBlockScreen(
                        onNavigateToAppDefense = { selectedScreenIndex = 3 }
                    )
                    2 -> AdaptiveAiScreen()
                    3 -> AppDefenseScreen()
                    4 -> EmergencyReportScreen(
                        onRunSimulation = { sim ->
                            val result = RiskEngine.analyze(
                                text = sim.sampleText,
                                source = "सुरक्षा सिमुलेशन: ${sim.title}"
                            )
                            SecurityRepository.recordScan(result)
                            selectedScreenIndex = 0 // jump to radar to view active scan results
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SuperAppTopBar(
    isShieldActive: Boolean,
    onToggleShield: () -> Unit,
    onDialEmergency: () -> Unit,
    isNotificationAccessGranted: Boolean,
    onRequestNotificationAccess: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberSurface)
            .border(1.dp, CyberBorder)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand Logo & Super App Tag
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(CyberPrimary.copy(alpha = 0.15f))
                        .border(1.dp, CyberPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Raksha AI",
                        tint = CyberPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "रक्षा AI",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(CyberPrimary)
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "SUPER V5",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberBackground
                            )
                        }
                    }
                    Text(
                        text = "साइबर फ्रॉड व मैलवेयर डिफेंस",
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }

            // Quick Actions: 1930 Speed Dial & Shield Switch
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberDangerBg)
                        .border(1.dp, CyberDanger, RoundedCornerShape(8.dp))
                        .clickable { onDialEmergency() }
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Call, contentDescription = "1930", tint = CyberDanger, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "1930", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CyberDanger)
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(if (isShieldActive) CyberSafeBg else CyberDangerBg)
                        .border(1.dp, if (isShieldActive) CyberSafe else CyberDanger, CircleShape)
                        .clickable { onToggleShield() }
                        .padding(6.dp)
                ) {
                    Icon(
                        imageVector = if (isShieldActive) Icons.Default.Shield else Icons.Default.Block,
                        contentDescription = "Shield",
                        tint = if (isShieldActive) CyberSafe else CyberDanger,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Notification permission reminder banner if missing
        if (!isNotificationAccessGranted) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(CyberWarningBg.copy(alpha = 0.5f))
                    .border(1.dp, CyberWarning.copy(alpha = 0.7f), RoundedCornerShape(6.dp))
                    .clickable { onRequestNotificationAccess() }
                    .padding(horizontal = 8.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = CyberWarning, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "रीयल-टाइम SMS व WhatsApp शील्ड अनुमति दें",
                        fontSize = 10.sp,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                }
                Text(
                    text = "अनुमति दें ▶",
                    fontSize = 10.sp,
                    color = CyberWarning,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
