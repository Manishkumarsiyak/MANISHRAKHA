package com.example

// Re-export V5 advanced neural RiskEngine to maintain full compatibility across namespaces
typealias ThreatLevel = com.rakshaai.v5.ThreatLevel
typealias ThreatOrigin = com.rakshaai.v5.ThreatOrigin
typealias ScamCategory = com.rakshaai.v5.ScamCategory
typealias AnalysisResult = com.rakshaai.v5.AnalysisResult
typealias AppRiskReport = com.rakshaai.v5.AppRiskReport
typealias RiskEngine = com.rakshaai.v5.RiskEngine
