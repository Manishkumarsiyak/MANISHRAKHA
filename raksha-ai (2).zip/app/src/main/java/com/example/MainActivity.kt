package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.ui.SecurityDashboardScreen
import com.example.ui.theme.MyApplicationTheme

/**
 * Raksha AI Main Activity - Subclasses V5 architecture for backward and forward compatibility.
 */
class MainActivity : com.rakshaai.v5.MainActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Raksha AI V5 $name", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun SecurityDashboardPreview() {
    MyApplicationTheme {
        SecurityDashboardScreen()
    }
}
