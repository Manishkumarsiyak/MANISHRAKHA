package com.example

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SecurityStats(
    val totalScanned: Int = 24,
    val threatsBlocked: Int = 8,
    val urlsScreened: Int = 18,
    val safeMessages: Int = 16,
    val appsAudited: Int = 32,
    val dangerousAppsFound: Int = 2,
    val itemsBlacklisted: Int = 4
)

enum class BlacklistType(val displayName: String, val badgeColorHex: Long) {
    PHONE_NUMBER("फ़ोन नंबर", 0xFFEF4444),
    SMS_SENDER_ID("SMS हैडर कोड", 0xFFF97316),
    CHAT_CONTACT("चैट कॉन्टैक्ट", 0xFF8B5CF6),
    MALICIOUS_APP("हानिकारक ऐप", 0xFFDC2626),
    PHISHING_DOMAIN("फिशिंग डोमेन", 0xFFEAB308)
}

data class BlacklistEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val type: BlacklistType,
    val target: String,
    val sourceApp: String,
    val reason: String,
    val riskCategory: ScamCategory,
    val timestamp: Long = System.currentTimeMillis()
)

data class ScamSimulation(
    val title: String,
    val subtitle: String,
    val category: ScamCategory,
    val sampleText: String
)

object SecurityRepository {

    private val _scanHistory = MutableStateFlow<List<AnalysisResult>>(emptyList())
    val scanHistory: StateFlow<List<AnalysisResult>> = _scanHistory.asStateFlow()

    private val _blacklist = MutableStateFlow<List<BlacklistEntry>>(emptyList())
    val blacklist: StateFlow<List<BlacklistEntry>> = _blacklist.asStateFlow()

    private val _stats = MutableStateFlow(SecurityStats())
    val stats: StateFlow<SecurityStats> = _stats.asStateFlow()

    private val _isShieldActive = MutableStateFlow(true)
    val isShieldActive: StateFlow<Boolean> = _isShieldActive.asStateFlow()

    private val _isAppInstallMonitorActive = MutableStateFlow(true)
    val isAppInstallMonitorActive: StateFlow<Boolean> = _isAppInstallMonitorActive.asStateFlow()

    private val _installedApps = MutableStateFlow<List<AppRiskReport>>(emptyList())
    val installedApps: StateFlow<List<AppRiskReport>> = _installedApps.asStateFlow()

    private val _isScanningApps = MutableStateFlow(false)
    val isScanningApps: StateFlow<Boolean> = _isScanningApps.asStateFlow()

    // Pre-loaded realistic scam simulations for instant testing
    val simulations = listOf(
        ScamSimulation(
            title = "Electricity Disconnection Alert",
            subtitle = "Disconnection alert tonight at 9:30 PM with personal phone number",
            category = ScamCategory.ELECTRICITY_BILL,
            sampleText = "Dear consumer, your electricity power will be disconnected tonight at 9:30 PM from the electricity office because your previous month bill was not updated. Please immediately contact our electricity officer at 9876543210. Discom Dept."
        ),
        ScamSimulation(
            title = "SBI Fake KYC APK Scam",
            subtitle = "Phishing domain urging APK download to unblock account",
            category = ScamCategory.BANKING_KYC,
            sampleText = "Dear SBI Customer, your NetBanking account has been suspended due to pending PAN KYC. Update immediately within 24 hours to avoid closure: http://sbi-kyc-update.xyz/SbiKycNet.apk"
        ),
        ScamSimulation(
            title = "Speed Post / India Post Parcel Scam",
            subtitle = "Fake undelivered courier demanding address update fee",
            category = ScamCategory.COURIER_POSTAL,
            sampleText = "Your India Post speed post parcel (IN8472910) cannot be delivered due to incomplete street address. Please update your address within 24 hours or package will be returned: http://indiapost-parcel-update.top/tracking"
        ),
        ScamSimulation(
            title = "UPI Reverse Payment Trap",
            subtitle = "Deceptive message asking for PIN to 'receive' money",
            category = ScamCategory.UPI_PAYMENT,
            sampleText = "OLX Buyer has sent you ₹15,000 for your sofa. Scan QR code and enter your UPI PIN to receive the payment credited into your bank account instantly."
        ),
        ScamSimulation(
            title = "Digital Arrest Notice",
            subtitle = "Impersonating Narcotics Bureau & Police video interrogation",
            category = ScamCategory.DIGITAL_ARREST,
            sampleText = "URGENT NOTICE: A parcel sent under your name containing 140g MDMA drugs was seized by Mumbai Customs. Digital arrest warrant issued by CBI. Join Skype video call immediately or face physical arrest."
        ),
        ScamSimulation(
            title = "Telegram Part-Time Job Scam",
            subtitle = "Daily ₹5000 earning promise by liking YouTube videos",
            category = ScamCategory.PART_TIME_JOB,
            sampleText = "Part time job opportunity! Earn 3000 to 5000 daily from home by just liking YouTube videos. Payout guaranteed every evening. Join our official Telegram group: http://bit.ly/earn-daily-payout"
        ),
        ScamSimulation(
            title = "Predatory Instant Loan Trap",
            subtitle = "Illegal loan app threatening to harvest contact list",
            category = ScamCategory.INSTANT_LOAN_EXTORTION,
            sampleText = "Congratulations! Instant cash loan of Rs 50,000 approved without CIBIL. Download FastCash app to disburse money directly into your account: http://fastcash-instant.xyz/download.apk"
        ),
        ScamSimulation(
            title = "Legitimate Bank Alert",
            subtitle = "Safe reference transaction from legitimate bank",
            category = ScamCategory.LEGITIMATE,
            sampleText = "Dear Customer, your A/C ending XX4921 has been debited by Rs 450.00 on 17-Sep-26 at Zomato UPI. Avail Bal: Rs 14,320.40. Call 1800112211 if not done by you. - State Bank of India"
        )
    )

    init {
        // Seed initial history with simulated detections so the user sees a rich, active dashboard immediately
        val initialItems = listOf(
            RiskEngine.analyze(
                text = "Dear user your power will be disconnected tonight. Contact electricity officer at 9821334455 immediately.",
                source = "SMS Notification",
                sender = "+91 98213 34455 (फर्जी अधिकारी)",
                packageName = "com.google.android.apps.messaging"
            ),
            RiskEngine.analyze(
                text = "HDFC Bank: Update your PAN card at http://hdfc-netbanking-alert.xyz/pan.apk to unblock your debit card.",
                source = "WhatsApp Alert",
                sender = "+91 88776 55443 (WhatsApp Forward)",
                packageName = "com.whatsapp"
            ),
            RiskEngine.analyze(
                text = "Speed Post alert: Your parcel detained due to incomplete address. Click http://indiapost-update.cam/parcels to pay Rs 5 re-delivery fee.",
                source = "SMS Notification",
                sender = "DM-INPOST (Spoofed SMS Header)",
                packageName = "com.google.android.apps.messaging"
            ),
            RiskEngine.analyze(
                text = "A/C XXXX1204 debited by Rs 1,200.00 on 16-Sep-26 at Grocery Mart. Avail Bal Rs 22,400.00.",
                source = "SMS Notification",
                sender = "VM-SBIBNK (प्रमाणित बैंक)",
                packageName = "com.google.android.apps.messaging"
            )
        )
        _scanHistory.value = initialItems

        // Initial sample audited apps to demonstrate app malware risk scoring
        _installedApps.value = listOf(
            AppRiskReport(
                packageName = "com.quicksupport.remote.fraud",
                appName = "AnySupport Remote",
                versionName = "2.4.1",
                isSideloaded = true,
                riskScore = 95,
                threatLevel = ThreatLevel.CRITICAL,
                dangerousPermissions = listOf(
                    "Accessibility Service (Screen capture & auto-tap)",
                    "System Alert Window (Draw fake overlay screens)",
                    "SMS Read / Receive (Banking OTP Interception)"
                ),
                threatBadges = listOf("Sideloaded APK", "Accessibility Abuser", "Banking Trojan Signature"),
                aiExplanation = "🚨 अत्यंत खतरनाक: यह ऐप असली बैंकिंग ऐप के ऊपर फर्जी स्क्रीन दिखाकर पासवर्ड व SMS OTP चुरा सकता है।",
                recommendation = "तुरंत अनइंस्टॉल करें!",
                isSystemApp = false
            ),
            AppRiskReport(
                packageName = "com.fastloan.instant.cash",
                appName = "Easy Rupee Credit",
                versionName = "1.0.8",
                isSideloaded = true,
                riskScore = 78,
                threatLevel = ThreatLevel.CRITICAL,
                dangerousPermissions = listOf(
                    "Read Contacts & Call Logs",
                    "Camera & Audio Recording",
                    "Precise GPS Tracking"
                ),
                threatBadges = listOf("Sideloaded APK", "Predatory Data Harvester"),
                aiExplanation = "⚠️ अवैध लोन ऐप: यह यूजर के फोन बुक व गैलरी का डेटा चुराकर ब्लैकमेल करने के लिए जाना जाता है।",
                recommendation = "ऐप सेटिंग्स में जाकर अभी हटाएं।",
                isSystemApp = false
            ),
            AppRiskReport(
                packageName = "com.google.android.apps.messaging",
                appName = "Messages",
                versionName = "2026.09",
                isSideloaded = false,
                riskScore = 0,
                threatLevel = ThreatLevel.SAFE,
                dangerousPermissions = listOf("SMS Read/Write"),
                threatBadges = listOf("Play Store Verified"),
                aiExplanation = "आधिकारिक मैसेजिंग ऐप। गूगल प्ले स्टोर द्वारा हस्ताक्षरित।",
                recommendation = "सुरक्षित ऐप।",
                isSystemApp = true
            ),
            RiskEngine.calculateAppRisk(
                packageName = "com.whatsapp",
                appName = "WhatsApp",
                versionName = "2.26.12",
                permissions = listOf("CAMERA", "RECORD_AUDIO", "READ_CONTACTS"),
                isSideloaded = false
            ),
            RiskEngine.calculateAppRisk(
                packageName = "com.phonepe.app",
                appName = "PhonePe",
                versionName = "24.08",
                permissions = listOf("ACCESS_FINE_LOCATION", "READ_SMS", "RECEIVE_SMS"),
                isSideloaded = false
            ),
            RiskEngine.calculateAppRisk(
                packageName = "com.facebook.katana",
                appName = "Facebook",
                versionName = "480.0",
                permissions = listOf("CAMERA", "ACCESS_FINE_LOCATION"),
                isSideloaded = false
            )
        )

        _blacklist.value = listOf(
            BlacklistEntry(
                type = BlacklistType.PHONE_NUMBER,
                target = "+91 98213 34455",
                sourceApp = "Google Messages (SMS)",
                reason = "फर्जी बिजली अधिकारी बनकर कनेक्शन काटने की धमकी",
                riskCategory = ScamCategory.ELECTRICITY_BILL
            ),
            BlacklistEntry(
                type = BlacklistType.CHAT_CONTACT,
                target = "+91 88776 55443",
                sourceApp = "WhatsApp",
                reason = "फर्जी HDFC बैंक PAN अपडेट APK लिंक फॉरवर्ड",
                riskCategory = ScamCategory.BANKING_KYC
            ),
            BlacklistEntry(
                type = BlacklistType.SMS_SENDER_ID,
                target = "DM-INPOST",
                sourceApp = "Google Messages (SMS)",
                reason = "स्पीड पोस्ट पार्सल डिटेन्ड री-डिलीवरी फिशिंग स्कैम",
                riskCategory = ScamCategory.COURIER_POSTAL
            ),
            BlacklistEntry(
                type = BlacklistType.MALICIOUS_APP,
                target = "com.quicksupport.remote.fraud",
                sourceApp = "AnySupport Remote",
                reason = "स्क्रीन रिकॉर्डिंग और बैंकिंग OTP चुराने वाला ट्रोजन",
                riskCategory = ScamCategory.MALWARE_APK
            ),
            BlacklistEntry(
                type = BlacklistType.PHISHING_DOMAIN,
                target = "sbi-kyc-update.xyz",
                sourceApp = "Google Chrome",
                reason = "नकली स्टेट बैंक ऑफ इंडिया फिशिंग सर्वर",
                riskCategory = ScamCategory.PHISHING_LINK
            )
        )

        _stats.value = SecurityStats(
            totalScanned = initialItems.size + 20,
            threatsBlocked = 8,
            urlsScreened = 18,
            safeMessages = 16,
            appsAudited = 34,
            dangerousAppsFound = 2,
            itemsBlacklisted = _blacklist.value.size
        )
    }

    fun setShieldActive(active: Boolean) {
        _isShieldActive.value = active
    }

    fun setAppInstallMonitorActive(active: Boolean) {
        _isAppInstallMonitorActive.value = active
    }

    fun addToBlacklist(entry: BlacklistEntry) {
        _blacklist.update { current ->
            if (current.none { it.target.equals(entry.target, ignoreCase = true) }) {
                listOf(entry) + current
            } else current
        }
        _stats.update { it.copy(itemsBlacklisted = _blacklist.value.size) }
    }

    fun removeFromBlacklist(id: String) {
        _blacklist.update { current -> current.filterNot { it.id == id } }
        _stats.update { it.copy(itemsBlacklisted = _blacklist.value.size) }
    }

    fun isBlacklisted(target: String): Boolean {
        val clean = target.trim().lowercase()
        return _blacklist.value.any { it.target.lowercase().contains(clean) || clean.contains(it.target.lowercase()) }
    }

    fun recordScan(result: AnalysisResult) {
        _scanHistory.update { listOf(result) + it.take(49) }
        _stats.update { current ->
            current.copy(
                totalScanned = current.totalScanned + 1,
                threatsBlocked = if (result.threatLevel == ThreatLevel.CRITICAL || result.threatLevel == ThreatLevel.HIGH_RISK) current.threatsBlocked + 1 else current.threatsBlocked,
                urlsScreened = current.urlsScreened + result.detectedUrls.size,
                safeMessages = if (result.threatLevel == ThreatLevel.SAFE) current.safeMessages + 1 else current.safeMessages
            )
        }
    }

    fun scanInstalledApps(context: Context) {
        CoroutineScope(Dispatchers.IO).launch {
            _isScanningApps.value = true
            try {
                val reports = RiskEngine.auditDeviceApps(context)
                if (reports.isNotEmpty()) {
                    _installedApps.value = reports
                    val dangerousCount = reports.count { it.threatLevel == ThreatLevel.CRITICAL || it.threatLevel == ThreatLevel.HIGH_RISK }
                    _stats.update { it.copy(appsAudited = reports.size, dangerousAppsFound = dangerousCount) }
                }
            } catch (_: Exception) {
            } finally {
                _isScanningApps.value = false
            }
        }
    }

    fun clearHistory() {
        _scanHistory.value = emptyList()
    }

    fun removeHistoryItem(id: String) {
        _scanHistory.update { it.filterNot { item -> item.id == id } }
    }
}
