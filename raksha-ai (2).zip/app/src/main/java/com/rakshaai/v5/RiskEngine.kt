package com.rakshaai.v5

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import java.util.UUID

enum class ThreatLevel {
    SAFE,
    LOW_RISK,
    HIGH_RISK,
    CRITICAL
}

enum class ScamCategory(val displayName: String, val hindiName: String) {
    BANKING_KYC("Banking & KYC Fraud", "बैंक / पैन केवाईसी फ्रॉड"),
    ELECTRICITY_BILL("Utility / Electricity Scam", "बिजली बिल कनेक्शन कटने का झांसा"),
    LOTTERY_PRIZE("Lottery & Free Reward Scam", "लॉटरी / लकी ड्रा धोखा"),
    PART_TIME_JOB("Task / Part-Time Job Scam", "टेलीग्राम / पार्ट-टाइम टास्क फ्रॉड"),
    UPI_PAYMENT("UPI & QR Code Trap", "UPI पिन / क्यूआर कोड रिवर्स फ्रॉड"),
    MALWARE_APK("Malicious App / APK Trap", "खतरनाक APK / मैलवेयर ऐप"),
    DIGITAL_ARREST("Digital Arrest / Police Threat", "डिजिटल अरेस्ट / पुलिस-कस्टम्स धमकी"),
    COURIER_POSTAL("Speed Post / Courier Scam", "स्पीड पोस्ट / पार्सल डिलीवरी फ्रॉड"),
    INSTANT_LOAN_EXTORTION("Predatory Loan Extortion", "फर्जी लोन ऐप ब्लैकमेल"),
    OTP_THEFT("OTP & Verification Stealing", "OTP चोरी / पासवर्ड जाल"),
    PHISHING_LINK("Phishing / Fake Link Trap", "फिशिंग / नकली लिंक ट्रैप"),
    UNKNOWN("Suspicious Pattern", "संदेहास्पद गतिविधि"),
    LEGITIMATE("Verified Safe Transaction", "प्रमाणित सुरक्षित लेन-देन")
}

data class ThreatOrigin(
    val appName: String = "अज्ञात स्रोत",
    val appPackage: String? = null,
    val senderNameOrNumber: String? = null,
    val channelType: String = "सिस्टम अलर्ट",
    val originDomainOrHost: String? = null,
    val deliveryMethod: String = "संदेश या नोटिफिकेशन",
    val preventionTip: String = "प्रेषक को तुरंत ब्लॉक करें और लिंक को न खोलें।"
)

data class AnalysisResult(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val source: String, // e.g. "SMS Alert", "WhatsApp", "Manual Scan", "App Install"
    val originalText: String,
    val threatLevel: ThreatLevel,
    val riskScore: Int, // 0 - 100
    val category: ScamCategory,
    val redFlags: List<String>,
    val detectedUrls: List<UrlCheckResult>,
    val recommendation: String,
    val aiReasoning: String = "",
    val origin: ThreatOrigin = ThreatOrigin()
)

/**
 * Information regarding verified high-trust ecosystem apps (WhatsApp, PhonePe, Google Pay, etc.)
 */
data class VerifiedEnterpriseInfo(
    val brandName: String,
    val company: String,
    val category: String,
    val inAppScamProtection: String
)

/**
 * Audit result for an installed or newly installed application on the user's phone.
 */
data class AppRiskReport(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val isSideloaded: Boolean,
    val riskScore: Int, // 0 to 100
    val threatLevel: ThreatLevel,
    val dangerousPermissions: List<String>,
    val threatBadges: List<String>,
    val aiExplanation: String,
    val recommendation: String,
    val isSystemApp: Boolean = false,
    val isVerifiedEnterpriseApp: Boolean = false,
    val enterpriseBrand: String? = null
)

object RiskEngine {

    // Keywords associated with different scam typologies
    private val ELECTRICITY_KEYWORDS = listOf(
        "electricity bill", "power will be disconnected", "bijli bill", "light cut",
        "officer number", "previous month bill not updated", "contact our electricity officer",
        "power disconnect tonight", "discom officer"
    )

    private val KYC_KEYWORDS = listOf(
        "kyc suspended", "kyc pending", "pan card not linked", "account will be blocked",
        "account blocked", "debit card inactive", "update pan immediately", "sim kyc",
        "netbanking blocked", "verify your account", "sbi reward points", "yono sbi kyc"
    )

    private val LOTTERY_KEYWORDS = listOf(
        "kbc lottery", "congratulations won", "won 25 lakh", "lottery winner",
        "claim your car", "free mobile recharge", "pm yojana claim", "lucky draw winner"
    )

    private val JOB_KEYWORDS = listOf(
        "part time job", "earn 3000 to 5000 daily", "youtube like and subscribe",
        "work from home earn", "simple tasks daily income", "telegram group join for payment",
        "daily payout guaranteed", "hotel review task"
    )

    private val UPI_KEYWORDS = listOf(
        "send 1 rs to receive", "enter upi pin to receive", "refund credit approved",
        "scan qr code to receive money", "accept money via upi pin", "pin to receive payment",
        "enter your upi pin", "enter upi pin", "upi pin to receive", "pin to receive",
        "scan qr code to receive", "scan this qr", "scan qr to receive", "upi pin"
    )

    private val DIGITAL_ARREST_KEYWORDS = listOf(
        "digital arrest", "customs parcel seized", "illegal drugs parcel", "cbi inquiry",
        "police arrest warrant", "cyber crime department notice", "stay on video call",
        "skype inquiry", "trai mobile disconnected"
    )

    private val COURIER_KEYWORDS = listOf(
        "india post parcel", "speed post detained", "address incomplete", "package cannot be delivered",
        "click link to update address", "courier holding charges", "delivery failed"
    )

    private val LOAN_KEYWORDS = listOf(
        "loan approved 50000", "instant loan without cibil", "download loan app",
        "repay loan or contacts", "micro loan approval", "loan disbursal link"
    )

    private val OTP_KEYWORDS = listOf(
        "share this otp", "send 6 digit code", "share verification code",
        "forward this sms", "otp to complete kyc"
    )

    private val URGENCY_TRIGGERS = listOf(
        "within 24 hours", "immediate action required", "otherwise blocked tonight at",
        "last date today", "urgent notice", "within 10 minutes", "without fail",
        "within 15 minutes", "tonight at 9:30"
    )

    // Verified Big Tech and Banking Ecosystem Apps (WhatsApp, PhonePe, Facebook, etc.)
    val VERIFIED_ENTERPRISE_APPS = mapOf(
        "com.whatsapp" to VerifiedEnterpriseInfo(
            brandName = "WhatsApp",
            company = "Meta Platforms Inc.",
            category = "मैसेजिंग व वॉयस कॉलिंग",
            inAppScamProtection = "व्हाट्सएप आधिकारिक ऐप है। रक्षा AI इस पर आने वाले फर्जी 'डिजिटल अरेस्ट' वीडियो कॉल, संदिग्ध APK फाइलों और लॉटरी ग्रुप्स को स्कैन कर रोकता है।"
        ),
        "com.whatsapp.w4b" to VerifiedEnterpriseInfo(
            brandName = "WhatsApp Business",
            company = "Meta Platforms Inc.",
            category = "बिजनेस मैसेजिंग",
            inAppScamProtection = "आधिकारिक बिजनेस ऐप। फर्जी कस्टमर केयर और पेमेंट लिंक से सुरक्षा।"
        ),
        "com.phonepe.app" to VerifiedEnterpriseInfo(
            brandName = "PhonePe",
            company = "PhonePe Pvt Ltd (NPCI/RBI)",
            category = "UPI एवं वित्तीय सेवाएं",
            inAppScamProtection = "PhonePe आधिकारिक व सुरक्षित ऐप है। रक्षा AI ठगों द्वारा भेजे जाने वाले 'पैसे पाने के लिए UPI पिन डालें' जैसे फर्जी कलेक्ट रिक्वेस्ट को ब्लॉक करता है।"
        ),
        "com.google.android.apps.nbu.paisa.user" to VerifiedEnterpriseInfo(
            brandName = "Google Pay",
            company = "Google LLC",
            category = "UPI एवं वित्तीय सेवाएं",
            inAppScamProtection = "Google Pay आधिकारिक ऐप है। अनजान लोगों द्वारा भेजे गए रिफंड/रिवर्स पेमेंट ट्रैप को रक्षा AI पकड़ता है।"
        ),
        "net.one97.paytm" to VerifiedEnterpriseInfo(
            brandName = "Paytm",
            company = "One97 Communications Ltd",
            category = "UPI एवं वॉलेट",
            inAppScamProtection = "Paytm आधिकारिक ऐप है। फर्जी पेटीएम कैशबैक लिंक और ऑडियो साउंडबॉक्स फ्रॉड से सुरक्षा।"
        ),
        "com.facebook.katana" to VerifiedEnterpriseInfo(
            brandName = "Facebook",
            company = "Meta Platforms Inc.",
            category = "सोशल मीडिया नेटवर्क",
            inAppScamProtection = "फेसबुक आधिकारिक ऐप है। फेसबुक फीड में दिखने वाले फर्जी पार्ट-टाइम जॉब विज्ञापनों और स्टॉक ट्रेडिंग पोंजी ग्रुप्स को रक्षा AI रोकता है।"
        ),
        "com.facebook.orca" to VerifiedEnterpriseInfo(
            brandName = "Messenger",
            company = "Meta Platforms Inc.",
            category = "मैसेजिंग",
            inAppScamProtection = "फेसबुक मैसेंजर पर रिश्तेदारों के क्लोन अकाउंट से पैसे मांगने वाली ठगी को रोकता है।"
        ),
        "com.instagram.android" to VerifiedEnterpriseInfo(
            brandName = "Instagram",
            company = "Meta Platforms Inc.",
            category = "सोशल मीडिया",
            inAppScamProtection = "इंस्टाग्राम सुरक्षित आधिकारिक ऐप है। फर्जी क्रिप्टो निवेश विज्ञापनों और टास्क जॉब्स को ब्लॉक करता है।"
        ),
        "com.sbi.lotuscustomer" to VerifiedEnterpriseInfo(
            brandName = "YONO SBI",
            company = "State Bank of India",
            category = "सरकारी बैंकिंग ऐप",
            inAppScamProtection = "SBI का असली ऐप 100% सुरक्षित है। रक्षा AI SMS में आने वाले फर्जी 'YONO KYC अपडेट' वाले क्लोन APK को पकड़ता है।"
        ),
        "com.snapwork.hdfc" to VerifiedEnterpriseInfo(
            brandName = "HDFC Bank MobileBanking",
            company = "HDFC Bank Ltd",
            category = "आधिकारिक बैंकिंग ऐप",
            inAppScamProtection = "HDFC बैंक का आधिकारिक ऐप।"
        ),
        "com.csam.icici.bank.imobile" to VerifiedEnterpriseInfo(
            brandName = "iMobile Pay",
            company = "ICICI Bank Ltd",
            category = "आधिकारिक बैंकिंग ऐप",
            inAppScamProtection = "ICICI बैंक का आधिकारिक ऐप।"
        ),
        "com.axis.mobile" to VerifiedEnterpriseInfo(
            brandName = "Axis Mobile",
            company = "Axis Bank Ltd",
            category = "आधिकारिक बैंकिंग ऐप",
            inAppScamProtection = "Axis बैंक का आधिकारिक ऐप।"
        ),
        "in.org.npci.upiapp" to VerifiedEnterpriseInfo(
            brandName = "BHIM UPI",
            company = "NPCI (भारत सरकार)",
            category = "राष्ट्रीय भुगतान निगम",
            inAppScamProtection = "भारत सरकार का आधिकारिक BHIM UPI ऐप।"
        ),
        "com.digilocker.android" to VerifiedEnterpriseInfo(
            brandName = "DigiLocker",
            company = "MeitY, Government of India",
            category = "डिजिटल इंडिया आधिकारिक ऐप",
            inAppScamProtection = "भारत सरकार का आधिकारिक राष्ट्रीय दस्तावेज वॉलेट।"
        )
    )

    // ==========================================
    // 1. APP PERMISSION & MALWARE RISK CALCULATOR
    // ==========================================

    /**
     * Calculates risk score for an installed or newly installed APK based on declared permissions and origin.
     */
    fun calculateAppRisk(
        packageName: String,
        appName: String,
        versionName: String,
        permissions: List<String>,
        isSideloaded: Boolean,
        isSystemApp: Boolean = false
    ): AppRiskReport {
        // Check for verified trusted enterprise apps first (WhatsApp, PhonePe, Facebook, etc.)
        val enterpriseInfo = VERIFIED_ENTERPRISE_APPS[packageName]
        if (enterpriseInfo != null) {
            return AppRiskReport(
                packageName = packageName,
                appName = appName.ifBlank { enterpriseInfo.brandName },
                versionName = versionName,
                isSideloaded = false,
                riskScore = 0,
                threatLevel = ThreatLevel.SAFE,
                dangerousPermissions = emptyList(),
                threatBadges = listOf("🛡️ प्रमाणित आधिकारिक कंपनी ऐप", enterpriseInfo.company, enterpriseInfo.category),
                aiExplanation = "✅ ${enterpriseInfo.brandName} (${enterpriseInfo.company}) एक प्रमाणित और विश्वस्त आधिकारिक एप्लिकेशन है। इसे गलती से भी मैलवेयर नहीं माना जाएगा।\n\n🛡️ इन-ऐप फ्रॉड शील्ड सक्रिय: ${enterpriseInfo.inAppScamProtection}",
                recommendation = "यह ऐप 100% सुरक्षित और विश्वसनीय है। रक्षा AI केवल इसके जरिए होने वाली बाहरी ठगी और फर्जी संदेशों को स्कैन कर रोकता है।",
                isSystemApp = false,
                isVerifiedEnterpriseApp = true,
                enterpriseBrand = enterpriseInfo.brandName
            )
        }

        if (isSystemApp) {
            return AppRiskReport(
                packageName = packageName,
                appName = appName,
                versionName = versionName,
                isSideloaded = false,
                riskScore = 0,
                threatLevel = ThreatLevel.SAFE,
                dangerousPermissions = emptyList(),
                threatBadges = listOf("System App"),
                aiExplanation = "Official Android system component verified by OS signature.",
                recommendation = "Safe system application.",
                isSystemApp = true
            )
        }

        val dangerous = mutableListOf<String>()
        val badges = mutableListOf<String>()
        var score = 0

        val hasAccessibility = permissions.any { it.contains("BIND_ACCESSIBILITY_SERVICE", ignoreCase = true) }
        val hasOverlay = permissions.any { it.contains("SYSTEM_ALERT_WINDOW", ignoreCase = true) }
        val hasSmsRead = permissions.any { it.contains("READ_SMS", ignoreCase = true) || it.contains("RECEIVE_SMS", ignoreCase = true) }
        val hasNotificationListen = permissions.any { it.contains("BIND_NOTIFICATION_LISTENER_SERVICE", ignoreCase = true) }
        val hasInstallPackages = permissions.any { it.contains("REQUEST_INSTALL_PACKAGES", ignoreCase = true) }
        val hasLocation = permissions.any { it.contains("ACCESS_FINE_LOCATION", ignoreCase = true) || it.contains("ACCESS_BACKGROUND_LOCATION", ignoreCase = true) }
        val hasAudio = permissions.any { it.contains("RECORD_AUDIO", ignoreCase = true) }
        val hasCamera = permissions.any { it.contains("CAMERA", ignoreCase = true) }
        val hasCallLog = permissions.any { it.contains("READ_CALL_LOG", ignoreCase = true) || it.contains("PROCESS_OUTGOING_CALLS", ignoreCase = true) }

        if (isSideloaded) {
            score += 35
            badges.add("Sideloaded APK (Untrusted Source)")
        }

        if (hasAccessibility) {
            score += 45
            dangerous.add("Accessibility Service (Screen reading & auto-clicking)")
            badges.add("Accessibility Abuser")
        }

        if (hasOverlay) {
            score += 35
            dangerous.add("System Alert Window (Draw overlay fake screens)")
            badges.add("Overlay Trap")
        }

        if (hasSmsRead) {
            score += 40
            dangerous.add("SMS Read / Receive (Banking OTP Interception)")
            badges.add("OTP Stealer")
        }

        if (hasNotificationListen) {
            score += 30
            dangerous.add("Notification Listener (Captures 2FA codes & messages)")
            badges.add("Notification Sniffer")
        }

        if (hasInstallPackages) {
            score += 25
            dangerous.add("Install Packages (Can drop secondary payloads)")
            badges.add("Malware Dropper")
        }

        if (hasCallLog) {
            score += 20
            dangerous.add("Call Log / Outgoing Calls Access")
        }

        if (hasLocation) {
            score += 15
            dangerous.add("Precise GPS Tracking")
        }

        if (hasAudio || hasCamera) {
            score += 15
            dangerous.add("Mic/Camera Access (Spyware Risk)")
        }

        // COMPOUND SIGNATURE CHECKS:
        // Banking Trojan Combo: Overlay + SMS
        if (hasOverlay && hasSmsRead) {
            score += 30
            badges.add("Banking Trojan Signature (Overlay + SMS)")
        }

        // RAT (Remote Access Trojan) Combo: Accessibility + Overlay
        if (hasAccessibility && hasOverlay) {
            score += 35
            badges.add("BankBot / Anatsa RAT Signature")
        }

        // Sideloaded + SMS: Classic malicious APK
        if (isSideloaded && hasSmsRead) {
            score += 25
            badges.add("Untrusted SMS Interceptor")
        }

        val finalScore = score.coerceIn(0, 100)
        val threatLevel = when {
            finalScore >= 75 -> ThreatLevel.CRITICAL
            finalScore >= 50 -> ThreatLevel.HIGH_RISK
            finalScore >= 25 -> ThreatLevel.LOW_RISK
            else -> ThreatLevel.SAFE
        }

        val aiExplanation = buildString {
            if (threatLevel == ThreatLevel.CRITICAL) {
                append("⚠️ उच्च खतरा (CRITICAL): यह ऐप संदिग्ध अनुमतियों (Permissions) का खतरनाक संयोजन मांगता है। ")
                if (hasOverlay && hasSmsRead) {
                    append("यह असली बैंकिंग ऐप के ऊपर फर्जी स्क्रीन दिखाकर आपका पासवर्ड और OTP चुरा सकता है। ")
                }
                if (hasAccessibility) {
                    append("एक्सेसिबिलिटी सर्विस से यह बिना आपकी जानकारी के स्क्रीन के बटन दबा सकता है। ")
                }
            } else if (threatLevel == ThreatLevel.HIGH_RISK) {
                append("⚠️ मध्यम-उच्च खतरा (HIGH RISK): यह ऐप बिना किसी स्पष्ट कारण के संवेदनशील डेटा (जैसे SMS या बैकग्राउंड लोकेशन) तक पहुंच मांगता है। ")
            } else {
                append("✅ सामान्य ऐप: कोई स्पष्ट मैलवेयर हस्ताक्षर या संदिग्ध संयोजन नहीं मिला।")
            }
        }

        val recommendation = when (threatLevel) {
            ThreatLevel.CRITICAL -> "🚨 तुरंत अनइंस्टॉल करें: यह ऐप आपकी बैंकिंग सुरक्षा और निजी डेटा के लिए गंभीर खतरा है।"
            ThreatLevel.HIGH_RISK -> "⚠️ अनुमतियों की जांच करें: यदि आप इस ऐप पर पूरी तरह भरोसा नहीं करते, तो इसे तुरंत हटाएं।"
            ThreatLevel.LOW_RISK -> "सामान्य सावधानी बरतें और केवल आवश्यक अनुमतियां ही दें।"
            ThreatLevel.SAFE -> "यह ऐप सुरक्षित प्रतीत होता है।"
        }

        return AppRiskReport(
            packageName = packageName,
            appName = appName,
            versionName = versionName,
            isSideloaded = isSideloaded,
            riskScore = finalScore,
            threatLevel = threatLevel,
            dangerousPermissions = dangerous,
            threatBadges = badges.distinct(),
            aiExplanation = aiExplanation,
            recommendation = recommendation,
            isSystemApp = false
        )
    }

    /**
     * Audits installed apps on the Android device, filtering out standard system packages.
     */
    fun auditDeviceApps(context: Context): List<AppRiskReport> {
        val pm = context.packageManager
        val reports = mutableListOf<AppRiskReport>()

        try {
            val packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
            for (pkg in packages) {
                val appInfo = pkg.applicationInfo ?: continue
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

                // Skip pure system apps unless they have critical permission anomalies
                if (isSystem && pkg.packageName != "com.google.android.apps.messaging") {
                    continue
                }

                // Check installer to see if sideloaded (from Chrome, WhatsApp, file manager)
                val installer = try {
                    pm.getInstallerPackageName(pkg.packageName)
                } catch (_: Exception) {
                    null
                }
                val isSideloaded = installer == null ||
                        installer.contains("packageinstaller") ||
                        installer.contains("chrome") ||
                        installer.contains("whatsapp") ||
                        installer.contains("telegram") ||
                        installer.contains("filemanager")

                val permissions = pkg.requestedPermissions?.toList() ?: emptyList()
                val appLabel = pm.getApplicationLabel(appInfo).toString()

                val report = calculateAppRisk(
                    packageName = pkg.packageName,
                    appName = appLabel,
                    versionName = pkg.versionName ?: "1.0",
                    permissions = permissions,
                    isSideloaded = isSideloaded,
                    isSystemApp = isSystem
                )

                // Only include apps that have at least some permissions requested
                if (report.riskScore > 0 || !isSystem) {
                    reports.add(report)
                }
            }
        } catch (_: Exception) {
            // Fallback for restricted permissions
        }

        return reports.sortedByDescending { it.riskScore }
    }

    // ==========================================
    // 2. SCAM NLP & AI CYBER FRAUD REASONING
    // ==========================================

    /**
     * Analyzes incoming message, notification or manually pasted text for cyber fraud patterns,
     * tracing the exact source app, sender ID, and threat origin vector.
     */
    fun analyze(
        text: String,
        source: String = "Manual Scan",
        sender: String? = null,
        packageName: String? = null
    ): AnalysisResult {
        val lower = text.lowercase()
        val redFlags = mutableListOf<String>()
        var score = 0
        var category = ScamCategory.UNKNOWN

        // 1. Extract and check embedded URLs and UPI links
        val extractedUrls = UrlChecker.extractUrls(text)
        val urlResults = extractedUrls.map { UrlChecker.checkUrl(it) }

        if (urlResults.isNotEmpty()) {
            val maxUrlScore = urlResults.maxOfOrNull { it.riskScore } ?: 0
            score += (maxUrlScore * 0.55).toInt()
            for (res in urlResults) {
                if (res.isSuspicious) {
                    redFlags.addAll(res.flags.map { "[लिंक चेतावनी] ${res.domain}: $it" })
                }
                if (res.upiDetails != null && res.upiDetails.isDeceptive) {
                    category = ScamCategory.UPI_PAYMENT
                }
            }
        }

        // 2. Check for Utility / Electricity Fraud
        val elecHits = ELECTRICITY_KEYWORDS.count { lower.contains(it) }
        if (elecHits >= 1) {
            category = ScamCategory.ELECTRICITY_BILL
            redFlags.add("बिजली बिल कनेक्शन कटने की धमकी वाला फर्जी पैटर्न मिला")
            score += 45 + (elecHits * 10)
        }

        // 3. Check for Banking / KYC Phishing
        val kycHits = KYC_KEYWORDS.count { lower.contains(it) }
        if (kycHits >= 1) {
            if (category == ScamCategory.UNKNOWN) category = ScamCategory.BANKING_KYC
            redFlags.add("अति-त्वरित बैंक/पैन खाता ब्लॉक होने की धमकी (KYC Trap)")
            score += 45 + (kycHits * 10)
        }

        // 4. Check for Lottery / Free Gift Scam
        val lotteryHits = LOTTERY_KEYWORDS.count { lower.contains(it) }
        if (lotteryHits >= 1) {
            if (category == ScamCategory.UNKNOWN) category = ScamCategory.LOTTERY_PRIZE
            redFlags.add("अविश्वसनीय लॉटरी या मुफ्त नकद इनाम का लालच")
            score += 50
        }

        // 5. Check for Part-Time Job / Task Scam
        val jobHits = JOB_KEYWORDS.count { lower.contains(it) }
        if (jobHits >= 1) {
            if (category == ScamCategory.UNKNOWN) category = ScamCategory.PART_TIME_JOB
            redFlags.add("टेलीग्राम / यूट्यूब लाइक करने पर दैनिक ₹3000-5000 कमाने का फर्जी लालच")
            score += 45
        }

        // 6. Check for UPI / QR Reverse Charge Fraud
        val isUpiPinTrap = (lower.contains("upi pin") || lower.contains("pin")) &&
                (lower.contains("receive") || lower.contains("credit") || lower.contains("accept money"))
        val upiHits = UPI_KEYWORDS.count { lower.contains(it) }
        if (upiHits >= 1 || isUpiPinTrap) {
            category = ScamCategory.UPI_PAYMENT
            redFlags.add("गंभीर UPI धोखा: पैसे प्राप्त करने के लिए कभी भी UPI PIN दर्ज नहीं किया जाता!")
            score += 65
        }

        // 7. Check for Digital Arrest & Law Enforcement Impersonation
        val arrestHits = DIGITAL_ARREST_KEYWORDS.count { lower.contains(it) }
        if (arrestHits >= 1) {
            category = ScamCategory.DIGITAL_ARREST
            redFlags.add("अत्यंत खतरनाक 'डिजिटल अरेस्ट' एवं फर्जी पुलिस/सीबीआई धमकी")
            score += 75
        }

        // 8. Check for Speed Post / Courier Parcel Scam
        val courierHits = COURIER_KEYWORDS.count { lower.contains(it) }
        if (courierHits >= 1) {
            if (category == ScamCategory.UNKNOWN) category = ScamCategory.COURIER_POSTAL
            redFlags.add("फर्जी स्पीड पोस्ट / पार्सल रोके जाने का लिंक घोटाला")
            score += 45
        }

        // 9. Check for Instant Predatory Loan App Blackmail
        val loanHits = LOAN_KEYWORDS.count { lower.contains(it) }
        if (loanHits >= 1) {
            if (category == ScamCategory.UNKNOWN) category = ScamCategory.INSTANT_LOAN_EXTORTION
            redFlags.add("अवैध माइक्रो-लोन ऐप ब्लैकमेल व संपर्क चुराने की साजिश")
            score += 55
        }

        // 10. Check for OTP Traps
        val otpHits = OTP_KEYWORDS.count { lower.contains(it) }
        if (otpHits >= 1) {
            if (category == ScamCategory.UNKNOWN) category = ScamCategory.OTP_THEFT
            redFlags.add("गोपनीय OTP या वेरिफिकेशन कोड साझा करने का दबाव")
            score += 60
        }

        // 11. Check for APK or sideloaded app lures
        if (lower.contains(".apk") || lower.contains("install app") || lower.contains("quicksupport") || lower.contains("anydesk")) {
            category = ScamCategory.MALWARE_APK
            redFlags.add("संदिग्ध APK या रिमोट कंट्रोल ऐप डाउनलोड करने का दबाव")
            score += 55
        }

        // 12. Artificial Urgency & Fear manipulation
        val urgencyHits = URGENCY_TRIGGERS.count { lower.contains(it) }
        if (urgencyHits >= 1) {
            redFlags.add("मानसिक दबाव और जल्दबाजी (Urgency Tactic) पैदा करने वाले शब्द मिले")
            score += 20
        }

        // 13. Dynamic Evolved AI Rules (Self-Learning Core)
        try {
            val activeAiRules = com.example.adaptive.AdaptiveCyberAI.evolvedRules.value.filter { it.isEnabled }
            for (rule in activeAiRules) {
                val matches = rule.patternKeywords.count { kw -> lower.contains(kw.lowercase()) }
                if (matches >= 2 || (rule.patternKeywords.size == 1 && matches == 1)) {
                    category = rule.scamCategory
                    redFlags.add("🧠 AI अनुकूलित नियम [${rule.title}]: नया फ्रॉड पैटर्न पहचाना गया")
                    score += rule.riskWeight
                }
            }
        } catch (_: Throwable) {}

        // 14. Active Blacklist Check
        try {
            val isKnownBlocked = com.example.SecurityRepository.isBlacklisted(text) ||
                (sender != null && com.example.SecurityRepository.isBlacklisted(sender)) ||
                (packageName != null && com.example.SecurityRepository.isBlacklisted(packageName))
            if (isKnownBlocked) {
                redFlags.add("🚫 सक्रिय ब्लॉकलिस्ट चेतावनी: प्रेषक, नंबर या ऐप ब्लॉकलिस्ट में दर्ज है!")
                score += 50
            }
        } catch (_: Throwable) {}

        // Legitimate Bank Transaction safeguard (detect standard RBI/Bank debit/credit alerts)
        val isStandardBankAlert = (lower.contains("debited by") || lower.contains("credited by")) &&
                (lower.contains("ac xxxx") || lower.contains("a/c") || lower.contains("bal")) &&
                urlResults.isEmpty() &&
                elecHits == 0 && kycHits == 0 && jobHits == 0 && courierHits == 0

        if (isStandardBankAlert && score < 30) {
            category = ScamCategory.LEGITIMATE
            score = 5
            redFlags.clear()
        }

        val finalScore = score.coerceIn(0, 100)

        val threatLevel = when {
            finalScore >= 75 -> ThreatLevel.CRITICAL
            finalScore >= 50 -> ThreatLevel.HIGH_RISK
            finalScore >= 25 -> ThreatLevel.LOW_RISK
            else -> ThreatLevel.SAFE
        }

        if (category == ScamCategory.UNKNOWN && threatLevel == ThreatLevel.SAFE) {
            category = ScamCategory.LEGITIMATE
        }

        val recommendation = generateRecommendation(threatLevel, category)
        val aiReasoning = generateAiReasoning(category, threatLevel, redFlags)
        val origin = detectOrigin(
            text = text,
            source = source,
            sender = sender,
            packageName = packageName,
            detectedUrls = urlResults,
            category = category
        )

        return AnalysisResult(
            source = source,
            originalText = text,
            threatLevel = threatLevel,
            riskScore = finalScore,
            category = category,
            redFlags = redFlags.distinct(),
            detectedUrls = urlResults,
            recommendation = recommendation,
            aiReasoning = aiReasoning,
            origin = origin
        )
    }

    private fun generateRecommendation(threatLevel: ThreatLevel, category: ScamCategory): String {
        return when (threatLevel) {
            ThreatLevel.CRITICAL -> when (category) {
                ScamCategory.UPI_PAYMENT -> "अपना UPI PIN कभी दर्ज न करें! याद रखें: पैसे प्राप्त करने के लिए कभी पिन नहीं लगता। इस संपर्क को तुरंत ब्लॉक करें।"
                ScamCategory.BANKING_KYC -> "धोखाधड़ी चेतावनी: किसी भी लिंक पर क्लिक न करें। बैंक कभी भी SMS लिंक द्वारा खाता बंद नहीं करते। अपनी आधिकारिक शाखा में जाएं।"
                ScamCategory.ELECTRICITY_BILL -> "बिजली विभाग कभी व्यक्तिगत मोबाइल नंबर से कॉल करने को नहीं कहता। बिल केवल आधिकारिक ऐप या बिजली काउंटर पर ही भरें।"
                ScamCategory.MALWARE_APK -> "इस APK फाइल को कभी इंस्टॉल न करें! इसमें ट्रोजन वायरस है जो आपके बैंकिंग OTP चुरा सकता है।"
                ScamCategory.DIGITAL_ARREST -> "भारत में 'डिजिटल अरेस्ट' नाम का कोई कानूनी प्रावधान नहीं है। कॉल तुरंत काटें और राष्ट्रीय साइबर हेल्पलाइन 1930 पर शिकायत करें।"
                ScamCategory.COURIER_POSTAL -> "स्पीड पोस्ट का पता अपडेट करने के लिए किसी अज्ञात लिंक पर ₹5 या ₹10 का भुगतान न करें।"
                ScamCategory.INSTANT_LOAN_EXTORTION -> "ऐसे किसी भी ऐप को अपने कॉन्टैक्ट्स या गैलरी की अनुमति न दें। यह ब्लैकमेलिंग गिरोह है।"
                else -> "खतरा: यह साइबर धोखाधड़ी की स्पष्ट कोशिश है। कोई भी वित्तीय जानकारी साझा न करें।"
            }
            ThreatLevel.HIGH_RISK -> when (category) {
                ScamCategory.PART_TIME_JOB -> "टास्क स्कैम: पहले छोटे-छोटे पैसे देकर भरोसा जीतेंगे, फिर लाखों रुपये जमा करवाकर ठग लेंगे। एक रुपया भी न भेजें।"
                ScamCategory.LOTTERY_PRIZE -> "लॉटरी फ्रॉड: जिस प्रतियोगिता में आपने भाग ही नहीं लिया, उसका इनाम कैसे मिल सकता है? टैक्स के नाम पर पैसे मांगे जाएंगे।"
                else -> "सचेत रहें: इस संदेश में दी गई जानकारी को आधिकारिक कस्टमर केयर से दोबारा सत्यापित करें।"
            }
            ThreatLevel.LOW_RISK -> "संदेश में कुछ संदेहास्पद संकेत मिले हैं। लिंक का डोमेन ध्यान से जांचें और पासवर्ड न डालें।"
            ThreatLevel.SAFE -> "यह संदेश या लेन-देन सामान्य और सुरक्षित प्रतीत होता है। सामान्य सतर्कता बनाए रखें।"
        }
    }

    private fun generateAiReasoning(category: ScamCategory, threatLevel: ThreatLevel, redFlags: List<String>): String {
        if (threatLevel == ThreatLevel.SAFE) {
            return "Raksha AI न्यूरल इंजन ने संदेश के पैटर्न का विश्लेषण किया। कोई फ़िशिंग लिंक, दुर्भावनापूर्ण कीवर्ड या मनोवैज्ञानिक दबाव का प्रमाण नहीं मिला।"
        }

        return buildString {
            append("🛡️ रक्षा AI गहन विश्लेषण:\n")
            when (category) {
                ScamCategory.ELECTRICITY_BILL -> {
                    append("• हथकंडा (Modus Operandi): ठग बिजली कटने का डर दिखाकर आधी रात में व्यक्तिगत नंबर पर संपर्क करने को कहते हैं, फिर AnyDesk या QuickSupport जैसे रिमोट ऐप डाउनलोड करवाकर खाता खाली करते हैं।\n")
                    append("• बचाव: बिजली बोर्ड कभी व्यक्तिगत नंबर नहीं भेजता। आधिकारिक पोर्टल से ही बिल भरें।")
                }
                ScamCategory.UPI_PAYMENT -> {
                    append("• हथकंडा (Modus Operandi): 'रिफंड' या 'कैशबैक' का झांसा देकर UPI Collect Request भेजते हैं या QR स्कैन करवाकर पिन डालने को कहते हैं।\n")
                    append("• स्वर्णिम नियम: UPI PIN केवल पैसे भेजने (DEBIT) के लिए होता है, प्राप्त (CREDIT) करने के लिए कभी नहीं!")
                }
                ScamCategory.DIGITAL_ARREST -> {
                    append("• हथकंडा (Modus Operandi): फर्जी पुलिस स्टेशन या कस्टम्स अधिकारी बनकर ड्रग्स पार्सल का झूठा आरोप लगाते हैं और वीडियो कॉल पर डराकर पैसे ट्रांसफर करवाते हैं।\n")
                    append("• सच्चाई: कानूनन किसी भी नागरिक को वीडियो कॉल पर अरेस्ट नहीं किया जा सकता।")
                }
                ScamCategory.BANKING_KYC -> {
                    append("• हथकंडा (Modus Operandi): पैन कार्ड या सिम ब्लॉक होने का डर पैदा करके फर्जी बैंक वेबसाइट या APK डाउनलोड करवाते हैं जो OTP चुरा लेता है।\n")
                    append("• बचाव: बैंक केवल रजिस्टर्ड ईमेल या आधिकारिक शाखा के माध्यम से ही KYC करते हैं।")
                }
                ScamCategory.COURIER_POSTAL -> {
                    append("• हथकंडा (Modus Operandi): अधूरा पता बताकर 5 रुपये का री-डिलीवरी चार्ज मांगते हैं। उस पेमेंट गेटवे से क्रेडिट/डेबिट कार्ड डेटा चोरी होता है।")
                }
                ScamCategory.PART_TIME_JOB -> {
                    append("• हथकंडा (Modus Operandi): टेलीग्राम ग्रुप में जोड़कर टास्क कराते हैं, फिर 'क्रिप्टो इन्वेस्टमेंट' के नाम पर लाखों रुपये फंसा लेते हैं।")
                }
                else -> {
                    append("• पाए गए खतरे: ${redFlags.take(3).joinToString(", ")}\n")
                    append("• सलाह: अज्ञात स्रोतों से आए किसी भी लिंक या फोन नंबर पर भरोसा न करें।")
                }
            }
        }
    }

    /**
     * Identifies the exact origin vector, sender identity, and source application for any threat.
     */
    fun detectOrigin(
        text: String,
        source: String = "Manual Scan",
        sender: String? = null,
        packageName: String? = null,
        detectedUrls: List<UrlCheckResult> = emptyList(),
        category: ScamCategory = ScamCategory.UNKNOWN
    ): ThreatOrigin {
        val lowerText = text.lowercase()
        val lowerSource = source.lowercase()

        // 1. Determine App Name & App Package
        var resolvedPackage = packageName
        val resolvedAppName = when {
            packageName != null -> getAppNameFromPackage(packageName)
            lowerSource.contains("whatsapp") -> {
                resolvedPackage = "com.whatsapp"
                "WhatsApp"
            }
            lowerSource.contains("telegram") -> {
                resolvedPackage = "org.telegram.messenger"
                "Telegram"
            }
            lowerSource.contains("sms") || lowerSource.contains("message") -> {
                resolvedPackage = "com.google.android.apps.messaging"
                "Google Messages (SMS)"
            }
            lowerSource.contains("chrome") || lowerSource.contains("browser") -> {
                resolvedPackage = "com.android.chrome"
                "Google Chrome"
            }
            lowerSource.contains("install") || lowerSource.contains("apk") -> {
                resolvedPackage = "com.google.android.packageinstaller"
                "Package Installer (APK)"
            }
            lowerSource.contains("manual") -> "AI Scanner (Manual Paste)"
            else -> source
        }

        // 2. Determine Channel Type
        val channelType = when {
            resolvedPackage?.contains("whatsapp") == true || lowerSource.contains("whatsapp") -> "WhatsApp चैट / मैसेज"
            resolvedPackage?.contains("telegram") == true || lowerSource.contains("telegram") -> "टेलीग्राम चैट / ग्रुप"
            resolvedPackage?.contains("messaging") == true || resolvedPackage?.contains("mms") == true || lowerSource.contains("sms") -> "सेलुलर SMS संदेश"
            resolvedPackage?.contains("chrome") == true || resolvedPackage?.contains("browser") == true || lowerSource.contains("browser") -> "वेब ब्राउज़र / डाउनलोड लिंक"
            resolvedPackage?.contains("packageinstaller") == true || lowerSource.contains("install") -> "सैलुलर APK इंस्टॉलेशन"
            lowerSource.contains("manual") -> "उपयोगकर्ता इनपुट (Manual Input)"
            else -> "इनकमिंग पुश नोटिफिकेशन"
        }

        // 3. Extract Sender Name / Phone Number / Bank Header
        var resolvedSender = sender?.trim()
        if (resolvedSender.isNullOrBlank()) {
            val phoneRegex = Regex("""(?:\+91[\-\s]?)?[6-9]\d{9}""")
            val phoneMatch = phoneRegex.find(text)

            val headerRegex = Regex("""\b[A-Za-z]{2}-[A-Za-z0-9]{5,7}\b""")
            val headerMatch = headerRegex.find(text)

            resolvedSender = when {
                phoneMatch != null -> "फ़ोन नंबर: ${phoneMatch.value}"
                headerMatch != null -> "SMS हैडर कोड: ${headerMatch.value}"
                lowerText.contains("discom") || lowerText.contains("electricity office") -> "बिजली विभाग का फर्जी अधिकारी"
                lowerText.contains("customs") || lowerText.contains("cbi") || lowerText.contains("police") -> "फर्जी पुलिस / कस्टम्स अधिकारी"
                lowerText.contains("olx buyer") -> "OLX फर्जी खरीदार"
                lowerText.contains("speed post") || lowerText.contains("india post") -> "फर्जी स्पीड पोस्ट प्रेषक"
                else -> "अज्ञात प्रेषक (Unknown Sender)"
            }
        }

        // 4. Extract Malicious Origin Domain / Web Server
        val originDomain = detectedUrls.firstOrNull()?.domain ?: run {
            val urlRegex = Regex("""https?://[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,}""")
            urlRegex.find(text)?.value?.removePrefix("http://")?.removePrefix("https://")?.substringBefore('/')
        }

        // 5. Determine Delivery Method
        val deliveryMethod = when {
            lowerText.contains(".apk") || lowerText.contains("install app") -> "असुरक्षित डायरेक्ट APK फ़ाइल डाउनलोड लिंक"
            lowerText.contains("upi://") || category == ScamCategory.UPI_PAYMENT -> "रिवर्स UPI पेमेंट रिक्वेस्ट / QR कोड जाल"
            category == ScamCategory.BANKING_KYC -> "फर्जी बैंक खाता सस्पेंशन चेतावनी व फिशिंग लिंक"
            category == ScamCategory.ELECTRICITY_BILL -> "बिजली बिल कनेक्शन कटने की धमकी और फर्जी कॉलबैक नंबर"
            category == ScamCategory.DIGITAL_ARREST -> "वीडियो कॉल पर फर्जी गिरफ्तारी का दबाव (Digital Arrest Trap)"
            category == ScamCategory.COURIER_POSTAL -> "अधूरे पते के नाम पर री-डिलीवरी शुल्क लिंक"
            category == ScamCategory.PART_TIME_JOB -> "यूट्यूब लाइक / पार्ट-टाइम जॉब के नाम पर टेलीग्राम लिंक"
            category == ScamCategory.INSTANT_LOAN_EXTORTION -> "बिना CIBIL तत्काल लोन ऐप डाउनलोड का लालच"
            originDomain != null -> "फिशिंग वेबसाइट लिंक ($originDomain)"
            else -> "सोशल इंजीनियरिंग टेक्स्ट संदेश"
        }

        // 6. Actionable Prevention Tip
        val preventionTip = when {
            resolvedSender.contains(Regex("""\d{10}""")) -> "इस फोन नंबर को तुरंत अपनी कॉलिंग व SMS ब्लॉकलिस्ट में डालें। इस पर कॉल या रिप्लाई न करें।"
            originDomain != null -> "सर्वर '$originDomain' को ब्राउज़र में कभी न खोलें और अपनी बैंक डिटेल्स दर्ज न करें।"
            lowerText.contains(".apk") -> "अपने डाउनलोड्स फोल्डर से इस APK फाइल को तुरंत डिलीट करें और इंस्टॉल न करें।"
            category == ScamCategory.UPI_PAYMENT -> "पैसे प्राप्त करने के लिए कभी भी UPI PIN न डालें या कोई भी QR कोड स्कैन न करें।"
            else -> "संदेश भेजने वाले को तुरंत ब्लॉक करें और साइबर हेल्पलाइन 1930 पर रिपोर्ट करें।"
        }

        return ThreatOrigin(
            appName = resolvedAppName,
            appPackage = resolvedPackage,
            senderNameOrNumber = resolvedSender,
            channelType = channelType,
            originDomainOrHost = originDomain,
            deliveryMethod = deliveryMethod,
            preventionTip = preventionTip
        )
    }

    private fun getAppNameFromPackage(pkg: String): String {
        return when {
            pkg.contains("whatsapp.w4b") -> "WhatsApp Business"
            pkg.contains("whatsapp") -> "WhatsApp"
            pkg.contains("telegram") -> "Telegram"
            pkg.contains("google.android.apps.messaging") -> "Google Messages (SMS)"
            pkg.contains("messaging") || pkg.contains("mms") -> "SMS / Messages"
            pkg.contains("chrome") -> "Google Chrome"
            pkg.contains("firefox") -> "Firefox Browser"
            pkg.contains("instagram") -> "Instagram"
            pkg.contains("facebook.orca") -> "Messenger"
            pkg.contains("facebook") -> "Facebook"
            pkg.contains("truecaller") -> "Truecaller"
            pkg.contains("packageinstaller") -> "Package Installer"
            else -> pkg.substringAfterLast('.')
        }
    }
}
