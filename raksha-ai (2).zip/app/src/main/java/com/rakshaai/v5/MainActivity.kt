package com.rakshaai.v5

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import com.example.ui.SuperAppNavigation
import com.example.ui.theme.MyApplicationTheme

/**
 * Raksha AI V5 - Next Level AI Cyber Fraud & Malware Shield
 * Super App Edition: Multi-screen Defense Architecture with
 * Real-time Radar, Threat Origin & Blacklist Hub, Adaptive Self-Learning AI,
 * Deep App Audit & Malware Quarantine, and Emergency 1930 Helpline.
 */
open class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                SuperAppNavigation()
            }
        }
    }
}
