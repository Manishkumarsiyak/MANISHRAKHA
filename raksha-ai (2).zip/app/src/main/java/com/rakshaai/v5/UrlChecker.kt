package com.rakshaai.v5

import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.Locale

/**
 * Result of evaluating a specific URL or UPI intent for cyber fraud, phishing, or malware risk.
 */
data class UrlCheckResult(
    val url: String,
    val domain: String,
    val isSuspicious: Boolean,
    val riskScore: Int, // 0 to 100
    val flags: List<String>,
    val upiDetails: UpiPaymentDetails? = null,
    val securityBadge: String = if (riskScore >= 70) "CRITICAL THREAT" else if (riskScore >= 40) "SUSPICIOUS" else "SAFE"
)

data class UpiPaymentDetails(
    val payeeVpa: String,
    val payeeName: String?,
    val amount: String?,
    val note: String?,
    val isDeceptive: Boolean,
    val warning: String?
)

object UrlChecker {

    // Regex to match URLs in text (including http, https, www, and upi:// protocols)
    private val URL_REGEX = Regex(
        "(?i)\\b((?:https?://|www\\d{0,3}[.]|[a-z0-9.\\-]+[.][a-z]{2,6}/|upi://pay\\?)(?:[^\\s()<>]+|\\((?:[^\\s()<>]+|(?:\\([^\\s()<>]+\\)))*\\))+(?:\\((?:[^\\s()<>]+|(?:\\([^\\s()<>]+\\)))*\\)|[^\\s`!()\\[\\]{};:'\".,<>?«»“”‘’]))",
        RegexOption.IGNORE_CASE
    )

    // High-abuse Top Level Domains commonly used for phishing & scams
    private val SUSPICIOUS_TLDS = setOf(
        "xyz", "top", "tk", "ml", "ga", "cf", "gq", "buzz", "work", "click", "loan",
        "cam", "live", "icu", "sbs", "rest", "surf", "monster", "bond", "quest", "cfd",
        "cyou", "vip", "club", "pw", "cc", "ws", "fit", "beauty"
    )

    // Known URL shortener services commonly leveraged to mask phishing destinations
    private val SHORTENER_DOMAINS = setOf(
        "bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly", "rb.gy", "shorturl.at",
        "ow.ly", "goo.gl", "buff.ly", "adf.ly", "bl.ink", "tiny.cc", "v.gd"
    )

    // Impersonated institutions in India (Banks, Utilities, Post, Telecom, Gov)
    private val IMPERSONATED_BRANDS = listOf(
        "sbi", "hdfc", "icici", "pnb", "axis", "kotak", "bob", "paytm", "phonepe",
        "gpay", "bhim", "aadhaar", "uidai", "incometax", "epfo", "amazon", "flipkart",
        "netflix", "telegram", "whatsapp", "bsnl", "jio", "airtel", "vi", "electricity",
        "indiapost", "speedpost", "echallan", "parivahan", "fastag"
    )

    // Legitimate primary domains for impersonated brands to prevent false alarms
    private val LEGITIMATE_ROOTS = setOf(
        "sbi.co.in", "onlinesbi.sbi", "hdfcbank.com", "icicibank.com", "pnbindia.in",
        "axisbank.com", "kotak.com", "bankofbaroda.in", "paytm.com", "phonepe.com",
        "google.com", "uidai.gov.in", "incometax.gov.in", "epfindia.gov.in",
        "indiapost.gov.in", "parivahan.gov.in", "echallan.parivahan.gov.in",
        "amazon.in", "amazon.com", "flipkart.com", "netflix.com", "telegram.org",
        "whatsapp.com", "jio.com", "airtel.in"
    )

    // Dangerous executable or package extensions indicating direct malware dropper
    private val DANGEROUS_EXTENSIONS = listOf(".apk", ".xapk", ".apks", ".exe", ".vbs", ".scr", ".bat", ".dex", ".jar")

    /**
     * Extracts all URLs and UPI intents from a given message text.
     */
    fun extractUrls(text: String): List<String> {
        return URL_REGEX.findAll(text)
            .map { it.value.trim() }
            .distinct()
            .toList()
    }

    /**
     * Analyzes an extracted URL or UPI string and returns threat scoring, flags, and breakdown.
     */
    fun checkUrl(rawUrl: String): UrlCheckResult {
        // Special Handling for UPI Deep Links (upi://pay?pa=...&pn=...)
        if (rawUrl.startsWith("upi://", ignoreCase = true)) {
            return checkUpiIntent(rawUrl)
        }

        val normalizedUrl = if (!rawUrl.startsWith("http://", ignoreCase = true) &&
            !rawUrl.startsWith("https://", ignoreCase = true)
        ) {
            "https://$rawUrl"
        } else {
            rawUrl
        }

        val flags = mutableListOf<String>()
        var score = 0

        val host = try {
            val uri = URI(normalizedUrl)
            uri.host?.lowercase(Locale.ROOT) ?: ""
        } catch (_: Exception) {
            normalizedUrl.substringAfter("://").substringBefore("/").lowercase(Locale.ROOT)
        }

        val lowerUrl = normalizedUrl.lowercase(Locale.ROOT)

        // 1. IP Address based host instead of registered domain
        if (isIpAddress(host)) {
            flags.add("IP-based URL ($host): hides domain ownership to bypass domain blacklists")
            score += 45
        }

        // 2. Direct APK / Executable download check (Malware dropper risk)
        for (ext in DANGEROUS_EXTENSIONS) {
            if (lowerUrl.contains(ext)) {
                flags.add("Direct installable file download ($ext) - High Trojan/RAT Risk")
                score += 55
                break
            }
        }

        // 3. Punycode & Homoglyph Lookalike attacks (e.g. xn-- or Cyrillic characters)
        if (host.startsWith("xn--") || containsHomoglyphs(host)) {
            flags.add("Homoglyph / Punycode character spoofing: mimics trusted characters with foreign lookalikes")
            score += 50
        }

        // 4. Suspicious or Free TLD check
        val tld = host.substringAfterLast('.', "")
        if (SUSPICIOUS_TLDS.contains(tld)) {
            flags.add("Suspicious top-level domain (.$tld) heavily abused by scam syndicates")
            score += 35
        }

        // 5. URL Shortener check (Obfuscation)
        if (SHORTENER_DOMAINS.any { host.contains(it) }) {
            flags.add("Shortened URL masks the true destination website")
            score += 25
        }

        // 6. Insecure HTTP on banking / sensitive keyword path
        if (normalizedUrl.startsWith("http://", ignoreCase = true)) {
            if (lowerUrl.contains("login") || lowerUrl.contains("bank") || lowerUrl.contains("kyc") || lowerUrl.contains("pay")) {
                flags.add("Unencrypted HTTP used on sensitive financial/login endpoint")
                score += 30
            } else {
                score += 10
            }
        }

        // 7. Brand Spoofing / Lookalike Domain Detection
        val isLegitimateRoot = LEGITIMATE_ROOTS.any { host == it || host.endsWith(".$it") }
        if (!isLegitimateRoot) {
            for (brand in IMPERSONATED_BRANDS) {
                if (host.contains(brand)) {
                    flags.add("Lookalike domain impersonating '$brand' without official credentials")
                    score += 45
                    break
                }
            }

            // Fake Government portal lure (e.g. *.gov-in.* or *-gov.* instead of *.gov.in)
            if ((host.contains("gov") || host.contains("nic")) && !host.endsWith(".gov.in") && !host.endsWith(".nic.in")) {
                flags.add("Deceptive government impersonation: domain is NOT an official .gov.in domain")
                score += 50
            }
        }

        // 8. Excessive hyphens or subdomain nesting (typical phishing pattern)
        if (host.count { it == '-' } >= 2) {
            flags.add("Excessive hyphens in domain name (common phishing evasion pattern)")
            score += 20
        }
        if (host.count { it == '.' } >= 3 && !isLegitimateRoot) {
            flags.add("Excessive subdomains masking destination domain")
            score += 15
        }

        val finalScore = score.coerceIn(0, 100)
        val isSuspicious = finalScore >= 35 || flags.isNotEmpty()

        return UrlCheckResult(
            url = rawUrl,
            domain = if (host.isNotBlank()) host else rawUrl,
            isSuspicious = isSuspicious,
            riskScore = finalScore,
            flags = flags
        )
    }

    /**
     * Decodes and validates UPI payment URLs to prevent deceptive debit traps.
     */
    private fun checkUpiIntent(upiUrl: String): UrlCheckResult {
        val flags = mutableListOf<String>()
        var score = 40 // Default caution on raw UPI links in text messages

        var payeeVpa = ""
        var payeeName = ""
        var amount = ""
        var note = ""

        try {
            val queryString = upiUrl.substringAfter("?", "")
            val pairs = queryString.split("&")
            for (pair in pairs) {
                val parts = pair.split("=")
                if (parts.size == 2) {
                    val key = parts[0].lowercase(Locale.ROOT)
                    val value = URLDecoder.decode(parts[1], StandardCharsets.UTF_8.name())
                    when (key) {
                        "pa" -> payeeVpa = value
                        "pn" -> payeeName = value
                        "am" -> amount = value
                        "tn" -> note = value
                    }
                }
            }
        } catch (_: Exception) {
            flags.add("Malformed UPI link parameters")
        }

        val lowerVpa = payeeVpa.lowercase(Locale.ROOT)
        val lowerName = payeeName.lowercase(Locale.ROOT)
        val lowerNote = note.lowercase(Locale.ROOT)

        // Check if personal UPI handles are masquerading as official brands or refunds
        val brandSpoof = IMPERSONATED_BRANDS.firstOrNull { lowerName.contains(it) || lowerNote.contains(it) }
        val isPersonalVpa = lowerVpa.contains("@okaxis") || lowerVpa.contains("@okhdfcbank") ||
                lowerVpa.contains("@paytm") || lowerVpa.contains("@ybl") || lowerVpa.contains("@ibl")

        var isDeceptive = false
        var warning: String? = null

        if (brandSpoof != null && isPersonalVpa) {
            isDeceptive = true
            warning = "Personal UPI handle ($payeeVpa) is impersonating official brand '$brandSpoof'"
            flags.add(warning)
            score += 45
        }

        if (amount.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0) > 0) {
            flags.add("DEBIT INTENT: Clicking this link will prompt you to PAY ₹$amount, NOT receive money!")
            score += 35
        }

        if (lowerNote.contains("refund") || lowerNote.contains("cashback") || lowerNote.contains("reward")) {
            flags.add("Deceptive transaction note: claims to be '$note' to trick user into paying")
            score += 30
        }

        val finalScore = score.coerceIn(0, 100)
        return UrlCheckResult(
            url = upiUrl,
            domain = payeeVpa.ifEmpty { "upi://pay" },
            isSuspicious = finalScore >= 50 || flags.isNotEmpty(),
            riskScore = finalScore,
            flags = flags,
            upiDetails = UpiPaymentDetails(
                payeeVpa = payeeVpa,
                payeeName = payeeName.ifEmpty { null },
                amount = amount.ifEmpty { null },
                note = note.ifEmpty { null },
                isDeceptive = isDeceptive,
                warning = warning
            )
        )
    }

    private fun isIpAddress(host: String): Boolean {
        val ipv4Regex = Regex("^(\\d{1,3}\\.){3}\\d{1,3}$")
        return ipv4Regex.matches(host)
    }

    private fun containsHomoglyphs(host: String): Boolean {
        // Look for Cyrillic / Greek characters frequently swapped into Latin ASCII domains
        for (char in host) {
            val block = Character.UnicodeBlock.of(char)
            if (block == Character.UnicodeBlock.CYRILLIC || block == Character.UnicodeBlock.GREEK) {
                return true
            }
        }
        return false
    }
}
