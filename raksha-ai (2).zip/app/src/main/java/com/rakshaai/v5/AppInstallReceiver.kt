package com.rakshaai.v5

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * Real-time BroadcastReceiver that monitors newly installed or updated applications on the device.
 * Immediately scans requested permissions for banking trojan, overlay, or SMS stealer signatures.
 */
class AppInstallReceiver : BroadcastReceiver() {

    companion object {
        const val APP_ALERT_CHANNEL_ID = "raksha_app_malware_channel"
        const val APP_ALERT_CHANNEL_NAME = "Raksha AI Malware & App Defense"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_PACKAGE_ADDED && action != Intent.ACTION_PACKAGE_REPLACED) {
            return
        }

        val packageName = intent.data?.schemeSpecificPart ?: return
        // Do not inspect our own app
        if (packageName == context.packageName) return

        try {
            val pm = context.packageManager
            val packageInfo = pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
            val appInfo = packageInfo.applicationInfo ?: return

            // Check if installed from untrusted source (sideloaded from browser, file manager, WhatsApp)
            val installer = try {
                pm.getInstallerPackageName(packageName)
            } catch (_: Exception) {
                null
            }
            val isSideloaded = installer == null ||
                    installer.contains("packageinstaller") ||
                    installer.contains("chrome") ||
                    installer.contains("whatsapp") ||
                    installer.contains("telegram") ||
                    installer.contains("filemanager")

            val permissions = packageInfo.requestedPermissions?.toList() ?: emptyList()
            val appLabel = pm.getApplicationLabel(appInfo).toString()
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0

            val report = RiskEngine.calculateAppRisk(
                packageName = packageName,
                appName = appLabel,
                versionName = packageInfo.versionName ?: "1.0",
                permissions = permissions,
                isSideloaded = isSideloaded,
                isSystemApp = isSystem
            )

            // If app is high risk or critical, trigger notification alert and record into repository
            if (report.threatLevel == ThreatLevel.CRITICAL || report.threatLevel == ThreatLevel.HIGH_RISK) {
                notifyUserOfThreat(context, report)

                // Also log as an analysis result so user can review it in the activity feed
                val result = AnalysisResult(
                    source = "App Install Shield: $appLabel",
                    originalText = "Newly installed package: $packageName. Perms: ${permissions.take(4).joinToString()}",
                    threatLevel = report.threatLevel,
                    riskScore = report.riskScore,
                    category = ScamCategory.MALWARE_APK,
                    redFlags = report.dangerousPermissions + report.threatBadges,
                    detectedUrls = emptyList(),
                    recommendation = report.recommendation,
                    aiReasoning = report.aiExplanation
                )
                com.example.SecurityRepository.recordScan(result)
            }
        } catch (_: Exception) {
            // Handle race condition or uninstalled package
        }
    }

    private fun notifyUserOfThreat(context: Context, report: AppRiskReport) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                APP_ALERT_CHANNEL_ID,
                APP_ALERT_CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Urgent alerts when a newly installed app has malware or trojan permissions"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Tap notification to open App Settings to uninstall easily
        val uninstallIntent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:${report.packageName}")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            report.packageName.hashCode(),
            uninstallIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, APP_ALERT_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("🚨 रक्षा AI: खतरनाक ऐप अलर्ट (${report.appName})")
            .setContentText("जोखिम स्कोर: ${report.riskScore}/100 - ${report.threatBadges.firstOrNull() ?: "संदिग्ध अनुमतियां"}")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("चेतावनी: नया ऐप '${report.appName}' में खतरनाक अनुमतियां पाई गईं:\n${report.dangerousPermissions.joinToString("\n• ", prefix = "• ")}\n${report.recommendation}")
            )
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .build()

        notificationManager.notify(report.packageName.hashCode(), notification)
    }
}
